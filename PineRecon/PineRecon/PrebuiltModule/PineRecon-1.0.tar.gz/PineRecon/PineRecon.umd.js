(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('@angular/router'), require('@angular/common'), require('@angular/cdk/a11y'), require('@angular/cdk/bidi'), require('@angular/cdk/observers'), require('@angular/cdk/overlay'), require('@angular/cdk/platform'), require('@angular/cdk/portal'), require('@angular/cdk/stepper'), require('@angular/cdk/table'), require('@angular/cdk/tree'), require('@angular/material/autocomplete'), require('@angular/material/badge'), require('@angular/material/bottom-sheet'), require('@angular/material/button'), require('@angular/material/button-toggle'), require('@angular/material/card'), require('@angular/material/checkbox'), require('@angular/material/chips'), require('@angular/material/core'), require('@angular/material/datepicker'), require('@angular/material/dialog'), require('@angular/material/divider'), require('@angular/material/expansion'), require('@angular/material/form-field'), require('@angular/material/grid-list'), require('@angular/material/icon'), require('@angular/material/input'), require('@angular/material/list'), require('@angular/material/menu'), require('@angular/material/paginator'), require('@angular/material/progress-bar'), require('@angular/material/progress-spinner'), require('@angular/material/radio'), require('@angular/material/select'), require('@angular/material/sidenav'), require('@angular/material/slide-toggle'), require('@angular/material/slider'), require('@angular/material/snack-bar'), require('@angular/material/sort'), require('@angular/material/stepper'), require('@angular/material/table'), require('@angular/material/tabs'), require('@angular/material/toolbar'), require('@angular/material/tooltip'), require('@angular/material/tree'), require('@angular/flex-layout'), require('@angular/forms')) :
    typeof define === 'function' && define.amd ? define('PineRecon', ['exports', '@angular/core', '@angular/common/http', '@angular/router', '@angular/common', '@angular/cdk/a11y', '@angular/cdk/bidi', '@angular/cdk/observers', '@angular/cdk/overlay', '@angular/cdk/platform', '@angular/cdk/portal', '@angular/cdk/stepper', '@angular/cdk/table', '@angular/cdk/tree', '@angular/material/autocomplete', '@angular/material/badge', '@angular/material/bottom-sheet', '@angular/material/button', '@angular/material/button-toggle', '@angular/material/card', '@angular/material/checkbox', '@angular/material/chips', '@angular/material/core', '@angular/material/datepicker', '@angular/material/dialog', '@angular/material/divider', '@angular/material/expansion', '@angular/material/form-field', '@angular/material/grid-list', '@angular/material/icon', '@angular/material/input', '@angular/material/list', '@angular/material/menu', '@angular/material/paginator', '@angular/material/progress-bar', '@angular/material/progress-spinner', '@angular/material/radio', '@angular/material/select', '@angular/material/sidenav', '@angular/material/slide-toggle', '@angular/material/slider', '@angular/material/snack-bar', '@angular/material/sort', '@angular/material/stepper', '@angular/material/table', '@angular/material/tabs', '@angular/material/toolbar', '@angular/material/tooltip', '@angular/material/tree', '@angular/flex-layout', '@angular/forms'], factory) :
    (global = global || self, factory(global.PineRecon = {}, global.ng.core, global.ng.common.http, global.ng.router, global.ng.common, global.ng.cdk.a11y, global.ng.cdk.bidi, global.ng.cdk.observers, global.ng.cdk.overlay, global.ng.cdk.platform, global.ng.cdk.portal, global.ng.cdk.stepper, global.ng.cdk.table, global.ng.cdk.tree, global.ng.material.autocomplete, global.ng.material.badge, global.ng.material.bottomSheet, global.ng.material.button, global.ng.material.buttonToggle, global.ng.material.card, global.ng.material.checkbox, global.ng.material.chips, global.ng.material.core, global.ng.material.datepicker, global.ng.material.dialog, global.ng.material.divider, global.ng.material.expansion, global.ng.material.formField, global.ng.material.gridList, global.ng.material.icon, global.ng.material.input, global.ng.material.list, global.ng.material.menu, global.ng.material.paginator, global.ng.material.progressBar, global.ng.material.progressSpinner, global.ng.material.radio, global.ng.material.select, global.ng.material.sidenav, global.ng.material.slideToggle, global.ng.material.slider, global.ng.material.snackBar, global.ng.material.sort, global.ng.material.stepper, global.ng.material.table, global.ng.material.tabs, global.ng.material.toolbar, global.ng.material.tooltip, global.ng.material.tree, global.ng.flexLayout, global.ng.forms));
}(this, (function (exports, core, http, router, common, a11y, bidi, observers, overlay, platform, portal, stepper, table, tree, autocomplete, badge, bottomSheet, button, buttonToggle, card, checkbox, chips, core$1, datepicker, dialog, divider, expansion, formField, gridList, icon, input, list, menu, paginator, progressBar, progressSpinner, radio, select, sidenav, slideToggle, slider, snackBar, sort, stepper$1, table$1, tabs, toolbar, tooltip, tree$1, flexLayout, forms) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __createBinding(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    }

    function __exportStar(m, exports) {
        for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var PineReconService = /** @class */ (function () {
        function PineReconService() {
        }
        PineReconService.ɵprov = core.ɵɵdefineInjectable({ factory: function PineReconService_Factory() { return new PineReconService(); }, token: PineReconService, providedIn: "root" });
        PineReconService = __decorate([
            core.Injectable({
                providedIn: 'root'
            })
        ], PineReconService);
        return PineReconService;
    }());

    var ApiService = /** @class */ (function () {
        function ApiService(http, router) {
            this.http = http;
            this.router = router;
            this.apiModuleBusy = document.getElementById('ApiModuleBusy');
            this.emptyResponse = { error: 'Request returned empty response' };
        }
        ApiService_1 = ApiService;
        ApiService.prototype.unauth = function () {
            localStorage.removeItem('authToken');
            if (this.router.url !== '/Login' && this.router.url !== '/Setup') {
                this.router.navigateByUrl('/Login');
            }
        };
        ApiService.prototype.setBusy = function () {
            this.apiModuleBusy.style.display = 'block';
        };
        ApiService.prototype.setNotBusy = function () {
            this.apiModuleBusy.style.display = 'none';
        };
        ApiService.extractBaseHref = function () {
            // Duplicated from injector because we have to be able to support
            // a static method here
            if (window['_app_base']) {
                if (window['_app_base'].endsWith('/')) {
                    return window['_app_base'].slice(0, -1);
                }
            }
            return window['_app_base'] || '';
        };
        ApiService.prototype.request = function (payload, callback) {
            var _this = this;
            this.setBusy();
            var resp;
            this.http.post(ApiService_1.extractBaseHref() + "/api/module/request", payload).subscribe(function (r) {
                if (r === undefined || r === null) {
                    resp = _this.emptyResponse;
                }
                else if (r.error) {
                    resp = r;
                }
                else {
                    resp = r.payload;
                }
            }, function (err) {
                resp = err.error;
                if (err.status === 401) {
                    _this.unauth();
                }
                _this.setNotBusy();
                callback(resp);
            }, function () {
                _this.setNotBusy();
                callback(resp);
            });
            ApiService_1.totalRequests++;
        };
        ApiService.prototype.APIGet = function (path, callback) {
            var _this = this;
            ApiService_1.totalRequests++;
            var resp;
            this.http.get("" + ApiService_1.extractBaseHref() + path).subscribe(function (r) {
                if (r === undefined || r === null) {
                    r = _this.emptyResponse;
                }
                resp = r;
            }, function (err) {
                resp = err.error;
                if (err.status === 401) {
                    _this.unauth();
                }
                callback(resp);
            }, function () {
                callback(resp);
            });
        };
        ApiService.prototype.APIGetAsync = function (path) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            ApiService_1.totalRequests++;
                            return [4 /*yield*/, this.http.get("" + ApiService_1.extractBaseHref() + path).toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        ApiService.prototype.APIPut = function (path, body, callback) {
            var _this = this;
            ApiService_1.totalRequests++;
            var resp;
            this.http.put("" + ApiService_1.extractBaseHref() + path, body).subscribe(function (r) {
                if (r === undefined || r === null) {
                    r = _this.emptyResponse;
                }
                resp = r;
            }, function (err) {
                resp = err.error;
                if (err.status === 401) {
                    _this.unauth();
                }
                callback(resp);
            }, function () {
                callback(resp);
            });
        };
        ApiService.prototype.APIPutAsync = function (path, body) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.http.put(ApiService_1.extractBaseHref() + "/" + path, body).toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        ApiService.prototype.APIPost = function (path, body, callback) {
            var _this = this;
            ApiService_1.totalRequests++;
            var resp;
            this.http.post("" + ApiService_1.extractBaseHref() + path, body).subscribe(function (r) {
                if (r === undefined || r === null) {
                    resp = _this.emptyResponse;
                }
                resp = r;
            }, function (err) {
                resp = err.error;
                if (err.status === 401) {
                    _this.unauth();
                }
                callback(resp);
            }, function () {
                callback(resp);
            });
        };
        ApiService.prototype.APIPostAsync = function (path, body) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.http.post(ApiService_1.extractBaseHref() + "/" + path, body).toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        ApiService.prototype.APIDelete = function (path, body, callback) {
            var _this = this;
            ApiService_1.totalRequests++;
            var opts = {
                headers: null,
                body: body
            };
            var resp;
            this.http.delete(ApiService_1.extractBaseHref() + "/" + path, opts).subscribe(function (r) {
                if (r === undefined || r === null) {
                    r = _this.emptyResponse;
                }
                resp = r;
            }, function (err) {
                resp = err.error;
                if (err.status === 401) {
                    _this.unauth();
                }
                callback(resp);
            }, function () {
                callback(resp);
            });
        };
        ApiService.prototype.APIDeleteAsync = function (path, body) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.http.delete("" + ApiService_1.extractBaseHref() + path, body).toPromise()];
                        case 1: return [2 /*return*/, _a.sent()];
                    }
                });
            });
        };
        ApiService.prototype.APIDownload = function (fullpath, filename) {
            ApiService_1.totalRequests++;
            var body = {
                filename: fullpath
            };
            this.http.post(ApiService_1.extractBaseHref() + "/api/download", body, { responseType: 'blob' }).subscribe(function (r) {
                var url = window.URL.createObjectURL(r);
                var a = document.createElement('a');
                document.body.appendChild(a);
                a.setAttribute('style', 'display: none');
                a.href = url;
                a.download = filename;
                a.click();
                window.URL.revokeObjectURL(url);
                a.remove();
            });
        };
        var ApiService_1;
        ApiService.totalRequests = 0;
        ApiService.ctorParameters = function () { return [
            { type: http.HttpClient },
            { type: router.Router }
        ]; };
        ApiService.ɵprov = core.ɵɵdefineInjectable({ factory: function ApiService_Factory() { return new ApiService(core.ɵɵinject(http.HttpClient), core.ɵɵinject(router.Router)); }, token: ApiService, providedIn: "root" });
        ApiService = ApiService_1 = __decorate([
            core.Injectable({
                providedIn: 'root'
            })
        ], ApiService);
        return ApiService;
    }());

    var PineReconComponent = /** @class */ (function () {
        function PineReconComponent(API) {
            this.API = API;
            this.logoPaths = [
                ApiService.extractBaseHref() + "/modules/PineRecon/assets/pinerecon-logo.png",
                ApiService.extractBaseHref() + "/modules/pinerecon/assets/pinerecon-logo.png",
                '/pineapple/ui/modules/PineRecon/assets/pinerecon-logo.png',
                '/pineapple/ui/modules/pinerecon/assets/pinerecon-logo.png',
                'assets/pinerecon-logo.png'
            ];
            this.logoPath = this.logoPaths[0];
            this.logoFailed = false;
            this.status = {
                internet: false,
                interfaces: [],
                oui_count: 0,
                has_hcxdumptool: false,
                has_hcxpcapngtool: false,
                has_aircrack: false,
                socket: '/tmp/modules/PineRecon.sock'
            };
            this.accessPoints = [];
            this.clients = [];
            this.captures = [];
            this.channelStats = [];
            this.securityStats = [];
            this.selectedAp = null;
            this.selectedClient = null;
            this.selectedCapture = null;
            this.activeCapture = null;
            this.selectedCaptureFile = '';
            this.selectedApDetail = 'security';
            this.handshakePreflight = null;
            this.pineDapBusy = false;
            this.pineDapMessage = '';
            this.scanning = false;
            this.capturing = false;
            this.dependencyBusy = false;
            this.dependencyChecked = false;
            this.statusLoaded = false;
            this.ouiChecked = false;
            this.loading = false;
            this.error = '';
            this.theme = 'dark';
            this.themes = [
                { value: 'dark', label: 'Pine Night' },
                { value: 'red', label: 'Red Zone' },
                { value: 'cobalt', label: 'Cobalt Grid' },
                { value: 'light', label: 'Light Ops' }
            ];
            this.band = 'both';
            this.scanTime = 15;
            this.captureDuration = 90;
            this.captureInterface = '';
            this.captureStartedAt = 0;
            this.scanId = '';
            this.scanPercent = 0;
            this.continuousScan = false;
            this.captureJobId = '';
            this.handshakeLog = '';
            this.lastUpdated = '';
            this.displayedColumns = ['signal', 'ssid', 'bssid', 'vendor', 'channel', 'security', 'wps', 'mfp', 'clients'];
            this.clientColumns = ['mac', 'ap', 'security', 'channel', 'data', 'lastSeen'];
            this.pageSize = 15;
            this.pageIndex = 0;
            this.clientPageIndex = 0;
            this.poller = null;
            this.logoIndex = 0;
            this.ouiRetryCount = 0;
        }
        PineReconComponent.prototype.ngOnInit = function () {
            this.loadSavedTheme();
            this.loadStatus();
            this.checkDependencies();
            this.loadRecon();
            this.loadCaptures();
        };
        PineReconComponent.prototype.ngOnDestroy = function () {
            if (this.poller) {
                clearInterval(this.poller);
            }
        };
        PineReconComponent.prototype.loadStatus = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'status' }, function (response) {
                if (response && !response.error) {
                    _this.status = response;
                    _this.statusLoaded = true;
                    if (!_this.captureInterface && response.interfaces && response.interfaces.length) {
                        _this.captureInterface = _this.preferredCaptureInterface(response.interfaces);
                    }
                    if (response.dependencies_installing && response.dependency_job_id) {
                        _this.dependencyBusy = true;
                        _this.pollDependencyJob(response.dependency_job_id);
                    }
                    if (!response.oui_count && _this.ouiRetryCount < 3) {
                        _this.retryOuiLoad();
                    }
                    else {
                        _this.ouiChecked = true;
                    }
                }
            });
        };
        PineReconComponent.prototype.checkDependencies = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'check_dependencies' }, function (response) {
                if (!response || response.error) {
                    return;
                }
                _this.status.has_dependencies = response.installed;
                _this.status.dependencies_installing = response.installing;
                _this.status.dependency_job_id = response.job_id;
                _this.status.dependency_packages = response.packages || _this.status.dependency_packages;
                _this.status.has_hcxdumptool = response.package_state ? response.package_state.hcxdumptool : _this.status.has_hcxdumptool;
                _this.status.has_hcxpcapngtool = response.package_state ? response.package_state.hcxpcapngtool : _this.status.has_hcxpcapngtool;
                _this.status.has_aircrack = response.package_state ? response.package_state['aircrack-ng'] : _this.status.has_aircrack;
                _this.status.has_airodump = response.package_state ? response.package_state['airodump-ng'] : _this.status.has_airodump;
                _this.status.capture_ready = response.capture_ready !== undefined ? response.capture_ready : response.installed;
                _this.status.capture_engine = response.capture_engine || _this.status.capture_engine;
                _this.dependencyChecked = true;
                if (response.installing && response.job_id) {
                    _this.dependencyBusy = true;
                    _this.pollDependencyJob(response.job_id);
                }
            });
        };
        PineReconComponent.prototype.reloadOuis = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'reload_ouis' }, function (response) {
                _this.ouiChecked = true;
                if (response && !response.error) {
                    _this.status.oui_count = response.oui_count;
                    _this.status.oui_path = response.oui_path;
                    _this.status.oui_error = response.oui_error;
                }
            });
        };
        PineReconComponent.prototype.startScan = function () {
            this.startRecon(this.scanTime, false);
        };
        PineReconComponent.prototype.startIndefiniteScan = function () {
            this.startRecon(0, true);
        };
        PineReconComponent.prototype.startRecon = function (scanTime, continuous) {
            var _this = this;
            this.error = '';
            this.scanning = true;
            this.loading = true;
            this.continuousScan = continuous;
            this.scanPercent = 0;
            this.API.APIPost('/api/recon/start', {
                live: true,
                scan_time: scanTime,
                band: this.band
            }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.scanning = false;
                    _this.loading = false;
                    return;
                }
                _this.scanId = response && (response.scanID || response.scan_id) ? (response.scanID || response.scan_id).toString() : '';
                _this.scanPercent = 0;
                _this.notifyScan('start', scanTime);
                _this.beginPolling();
            });
        };
        PineReconComponent.prototype.stopScan = function () {
            var _this = this;
            this.API.APIPost('/api/recon/stop', {}, function () {
                _this.scanning = false;
                _this.loading = false;
                _this.continuousScan = false;
                if (_this.poller) {
                    clearInterval(_this.poller);
                    _this.poller = null;
                }
                _this.notifyScan('stop', 0);
                _this.loadRecon();
            });
        };
        PineReconComponent.prototype.refresh = function () {
            this.ouiRetryCount = 0;
            this.ouiChecked = false;
            this.loadStatus();
            this.checkDependencies();
            this.loadRecon();
            this.loadCaptures();
        };
        PineReconComponent.prototype.installDependencies = function () {
            var _this = this;
            this.dependencyBusy = true;
            this.API.request({ module: 'PineRecon', action: 'manage_dependencies', install: true }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.dependencyBusy = false;
                    return;
                }
                if (response && response.installed) {
                    _this.dependencyBusy = false;
                    _this.checkDependencies();
                    _this.loadStatus();
                    return;
                }
                _this.pollDependencyJob(response.job_id);
            });
        };
        PineReconComponent.prototype.startHandshakeCapture = function () {
            var _this = this;
            if (!this.selectedAp) {
                this.error = 'Select an access point before starting a handshake capture.';
                return;
            }
            this.error = '';
            if (!this.captureInterface && this.status.interfaces && this.status.interfaces.length) {
                this.captureInterface = this.preferredCaptureInterface(this.status.interfaces);
            }
            if (!this.captureInterface) {
                this.error = 'Select a capture interface before starting a handshake capture.';
                return;
            }
            this.runHandshakePreflight(function (ready) {
                if (!ready) {
                    return;
                }
                _this.runHandshakeCapture();
            });
        };
        PineReconComponent.prototype.startPineDap = function () {
            var _this = this;
            if (!this.selectedAp) {
                this.error = 'Select an access point before starting Pine DAP.';
                return;
            }
            this.error = '';
            this.pineDapBusy = true;
            this.pineDapMessage = 'Starting native PineAP handshake capture...';
            this.API.request({
                module: 'PineRecon',
                action: 'start_pineap_handshake',
                bssid: this.selectedAp.bssid,
                channel: this.selectedAp.channel
            }, function (response) {
                _this.pineDapBusy = false;
                if (response && response.error) {
                    _this.error = response.error.message || response.error || 'Pine DAP failed to start.';
                    _this.pineDapMessage = '';
                    return;
                }
                _this.pineDapMessage = "Pine DAP started for " + _this.selectedAp.ssid + " on CH " + _this.selectedAp.channel + ".";
            });
        };
        PineReconComponent.prototype.stopPineDap = function () {
            var _this = this;
            this.pineDapBusy = true;
            this.API.request({ module: 'PineRecon', action: 'stop_pineap_handshake' }, function (response) {
                _this.pineDapBusy = false;
                if (response && response.error) {
                    _this.error = response.error.message || response.error || 'Pine DAP stop failed.';
                    return;
                }
                _this.pineDapMessage = 'Pine DAP stopped.';
            });
        };
        PineReconComponent.prototype.runHandshakeCapture = function () {
            var _this = this;
            this.capturing = true;
            this.captureStartedAt = Date.now();
            this.API.request({
                module: 'PineRecon',
                action: 'start_handshake_capture',
                interface: this.captureInterface,
                bssid: this.selectedAp.bssid,
                channel: this.selectedAp.channel,
                duration: this.captureDuration
            }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.capturing = false;
                    _this.captureStartedAt = 0;
                    return;
                }
                _this.captureJobId = response.job_id;
                _this.activeCapture = _this.emptyCaptureReport(response.output_file || 'running-capture');
                _this.handshakeLog = '';
                _this.pollCaptureJob();
            });
        };
        PineReconComponent.prototype.runHandshakePreflight = function (callback) {
            var _this = this;
            this.API.request({
                module: 'PineRecon',
                action: 'handshake_preflight',
                interface: this.captureInterface,
                channel: this.selectedAp ? this.selectedAp.channel : ''
            }, function (response) {
                if (response && response.error) {
                    _this.error = response.error.message || response.error || 'Handshake preflight failed.';
                    if (callback) {
                        callback(false);
                    }
                    return;
                }
                _this.handshakePreflight = response;
                if (!response.ready) {
                    _this.error = (response.blockers || ['Handshake preflight failed.']).join(' ');
                }
                if (callback) {
                    callback(!!response.ready);
                }
            });
        };
        PineReconComponent.prototype.stopHandshakeCapture = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'stop_handshake_capture', job_id: this.captureJobId }, function () {
                _this.capturing = false;
                _this.captureStartedAt = 0;
                _this.captureJobId = '';
                _this.loadCaptures();
            });
        };
        PineReconComponent.prototype.selectAp = function (ap) {
            this.selectedAp = ap;
            this.selectedApDetail = 'security';
        };
        PineReconComponent.prototype.selectClient = function (client) {
            this.selectedClient = client;
            var ap = this.accessPoints.find(function (candidate) {
                return (candidate.bssid || '').toUpperCase() === (client.apBssid || '').toUpperCase();
            });
            if (ap) {
                this.selectedAp = ap;
            }
        };
        PineReconComponent.prototype.startClientHandshake = function () {
            var _this = this;
            if (!this.selectedClient) {
                this.error = 'Select a client first.';
                return;
            }
            var ap = this.accessPoints.find(function (candidate) {
                return (candidate.bssid || '').toUpperCase() === (_this.selectedClient.apBssid || '').toUpperCase();
            });
            if (!ap) {
                this.error = 'Selected client is not associated with a targetable AP.';
                return;
            }
            this.selectedAp = ap;
            this.startHandshakeCapture();
        };
        PineReconComponent.prototype.selectCapture = function (capture) {
            this.selectedCapture = capture;
            this.selectedCaptureFile = capture ? capture.file : '';
            this.handshakeLog = capture.log_tail || this.handshakeLog;
        };
        PineReconComponent.prototype.selectCaptureByFile = function (fileName) {
            var capture = this.captures.find(function (candidate) { return candidate.file === fileName; });
            if (capture) {
                this.selectCapture(capture);
            }
        };
        PineReconComponent.prototype.refreshCaptures = function () {
            this.loadCaptures();
        };
        PineReconComponent.prototype.downloadSelectedCapture = function () {
            if (!this.selectedCapture) {
                return;
            }
            this.downloadCapture(this.selectedCapture);
        };
        PineReconComponent.prototype.downloadCapture = function (capture) {
            var _this = this;
            if (!capture) {
                return;
            }
            this.API.request({ module: 'PineRecon', action: 'download_capture', file: capture.file }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    return;
                }
                var binary = atob(response.content_b64 || '');
                var bytes = new Uint8Array(binary.length);
                for (var index = 0; index < binary.length; index++) {
                    bytes[index] = binary.charCodeAt(index);
                }
                var blob = new Blob([bytes], { type: response.mime || 'application/vnd.tcpdump.pcap' });
                var url = window.URL.createObjectURL(blob);
                var link = document.createElement('a');
                link.href = url;
                link.download = response.file || capture.file;
                link.click();
                window.URL.revokeObjectURL(url);
            });
        };
        PineReconComponent.prototype.downloadCaptureFromMenu = function (event, capture) {
            event.stopPropagation();
            this.downloadCapture(capture);
        };
        PineReconComponent.prototype.deleteSelectedCapture = function () {
            if (!this.selectedCapture) {
                return;
            }
            this.deleteCapture(this.selectedCapture);
        };
        PineReconComponent.prototype.deleteCaptureFromMenu = function (event, capture) {
            event.stopPropagation();
            this.deleteCapture(capture);
        };
        PineReconComponent.prototype.deleteCapture = function (capture) {
            var _this = this;
            if (!capture) {
                return;
            }
            var file = capture.file;
            this.API.request({ module: 'PineRecon', action: 'delete_capture', file: file }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    return;
                }
                _this.captures = _this.captures.filter(function (capture) { return capture.file !== file; });
                if (_this.selectedCapture && _this.selectedCapture.file === file) {
                    _this.selectedCapture = _this.captures.length ? _this.captures[0] : null;
                }
                _this.selectedCaptureFile = _this.selectedCapture ? _this.selectedCapture.file : '';
                if (!_this.selectedCapture) {
                    _this.handshakeLog = '';
                }
            });
        };
        PineReconComponent.prototype.eapolCount = function (capture, message) {
            return capture && capture.message_counts ? (capture.message_counts[message] || 0) : 0;
        };
        PineReconComponent.prototype.handshakeReport = function () {
            return this.activeCapture || this.selectedCapture;
        };
        PineReconComponent.prototype.captureReady = function () {
            return !!(this.status.capture_ready || this.status.has_hcxdumptool || this.status.has_airodump);
        };
        PineReconComponent.prototype.captureEngineLabel = function () {
            if (this.status.capture_engine) {
                return this.status.capture_engine;
            }
            if (this.status.has_hcxdumptool) {
                return 'hcxdumptool';
            }
            if (this.status.has_airodump) {
                return 'airodump-ng';
            }
            return 'No capture engine';
        };
        PineReconComponent.prototype.captureStatusLabel = function (capture) {
            if (!capture) {
                return 'none';
            }
            if ((capture.pmkid_hashes || 0) > 0) {
                return 'PMKID usable';
            }
            if ((capture.eapol_hashes || 0) > 0) {
                return 'EAPOL usable';
            }
            if (capture.complete) {
                return 'complete';
            }
            if (capture.accepted) {
                return 'usable pair';
            }
            if (capture.partial || capture.accepted || capture.eapol_frames > 0) {
                return 'partial';
            }
            return 'no EAPOL';
        };
        PineReconComponent.prototype.captureDurationLabel = function () {
            return Number(this.captureDuration) === 0 ? 'indefinite' : this.captureDuration + "s";
        };
        PineReconComponent.prototype.captureElapsedLabel = function () {
            if (!this.captureStartedAt) {
                return '00:00';
            }
            var seconds = Math.max(0, Math.floor((Date.now() - this.captureStartedAt) / 1000));
            var minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
            var remainder = (seconds % 60).toString().padStart(2, '0');
            return minutes + ":" + remainder;
        };
        PineReconComponent.prototype.hasSecurityDetails = function (ap) {
            return !!(ap && ap.securityDetails && (ap.securityDetails.authentication.length ||
                ap.securityDetails.groupCiphers.length ||
                ap.securityDetails.pairwiseCiphers.length ||
                ap.securityDetails.summary));
        };
        PineReconComponent.prototype.hasTaggedParameters = function (ap) {
            return !!(ap && ap.taggedParameters && ap.taggedParameters.length);
        };
        PineReconComponent.prototype.onThemeChange = function (theme) {
            this.theme = theme;
            try {
                localStorage.setItem('PineRecon.theme', theme);
            }
            catch (error) { }
        };
        PineReconComponent.prototype.onLogoError = function () {
            this.logoIndex++;
            if (this.logoIndex < this.logoPaths.length) {
                this.logoPath = this.logoPaths[this.logoIndex];
            }
            else {
                this.logoFailed = true;
            }
        };
        Object.defineProperty(PineReconComponent.prototype, "pagedAccessPoints", {
            get: function () {
                var start = this.pageIndex * this.pageSize;
                return this.accessPoints.slice(start, start + this.pageSize);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PineReconComponent.prototype, "pagedClients", {
            get: function () {
                var start = this.clientPageIndex * this.pageSize;
                return this.clients.slice(start, start + this.pageSize);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PineReconComponent.prototype, "apPageCount", {
            get: function () {
                return Math.max(1, Math.ceil(this.accessPoints.length / this.pageSize));
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PineReconComponent.prototype, "clientPageCount", {
            get: function () {
                return Math.max(1, Math.ceil(this.clients.length / this.pageSize));
            },
            enumerable: true,
            configurable: true
        });
        PineReconComponent.prototype.nextApPage = function () {
            this.pageIndex = Math.min(this.pageIndex + 1, this.apPageCount - 1);
        };
        PineReconComponent.prototype.prevApPage = function () {
            this.pageIndex = Math.max(this.pageIndex - 1, 0);
        };
        PineReconComponent.prototype.nextClientPage = function () {
            this.clientPageIndex = Math.min(this.clientPageIndex + 1, this.clientPageCount - 1);
        };
        PineReconComponent.prototype.prevClientPage = function () {
            this.clientPageIndex = Math.max(this.clientPageIndex - 1, 0);
        };
        PineReconComponent.prototype.downloadLogs = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'get_logs' }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    return;
                }
                var content = '';
                Object.keys(response || {}).forEach(function (name) {
                    content += "===== " + name + " =====\n" + response[name] + "\n\n";
                });
                var blob = new Blob([content], { type: 'text/plain' });
                var url = window.URL.createObjectURL(blob);
                var link = document.createElement('a');
                link.href = url;
                link.download = "PineRecon-logs-" + new Date().toISOString() + ".txt";
                link.click();
                window.URL.revokeObjectURL(url);
            });
        };
        PineReconComponent.prototype.signalBars = function (signal) {
            var strength = this.signalPercent(signal);
            var filled = strength > 80 ? 4 : strength > 58 ? 3 : strength > 34 ? 2 : strength > 12 ? 1 : 0;
            var bars = [];
            for (var i = 0; i < 4; i++) {
                bars.push(i < filled ? 1 : 0);
            }
            return bars;
        };
        PineReconComponent.prototype.signalPercent = function (signal) {
            var clamped = Math.max(-95, Math.min(-30, signal || -95));
            return Math.round(((clamped + 95) / 65) * 100);
        };
        PineReconComponent.prototype.trackByBssid = function (index, ap) {
            return ap.bssid || index.toString();
        };
        PineReconComponent.prototype.beginPolling = function () {
            var _this = this;
            if (this.poller) {
                clearInterval(this.poller);
            }
            this.loadRecon();
            this.poller = setInterval(function () { return _this.checkScanStatus(); }, 2500);
        };
        PineReconComponent.prototype.retryOuiLoad = function () {
            var _this = this;
            this.ouiRetryCount++;
            setTimeout(function () {
                _this.API.request({ module: 'PineRecon', action: 'reload_ouis' }, function (response) {
                    if (response && !response.error && response.oui_count) {
                        _this.status.oui_count = response.oui_count;
                        _this.status.oui_path = response.oui_path;
                        _this.status.oui_error = response.oui_error;
                        _this.ouiChecked = true;
                        return;
                    }
                    if (_this.ouiRetryCount < 3) {
                        _this.retryOuiLoad();
                    }
                    else {
                        _this.ouiChecked = true;
                        if (response && !response.error) {
                            _this.status.oui_error = response.oui_error || _this.status.oui_error;
                        }
                    }
                });
            }, 900);
        };
        PineReconComponent.prototype.notifyScan = function (event, duration) {
            this.API.request({
                module: 'PineRecon',
                action: 'scan_notification',
                event: event,
                duration: duration,
                band: this.band
            }, function () { });
        };
        PineReconComponent.prototype.loadSavedTheme = function () {
            try {
                var savedTheme_1 = localStorage.getItem('PineRecon.theme');
                if (savedTheme_1 && this.themes.some(function (option) { return option.value === savedTheme_1; })) {
                    this.theme = savedTheme_1;
                }
            }
            catch (error) { }
        };
        PineReconComponent.prototype.emptyCaptureReport = function (file) {
            return {
                file: file,
                size: 0,
                modified: '',
                eapol_frames: 0,
                pmkid_hashes: 0,
                eapol_hashes: 0,
                hash_lines: 0,
                messages: [],
                message_counts: { M1: 0, M2: 0, M3: 0, M4: 0 },
                usable_pairs: [],
                complete: false,
                partial: false,
                accepted: false,
                confidence: 'none',
                validation_tool: 'fallback',
                hash_file: '',
                message_pairs: []
            };
        };
        PineReconComponent.prototype.preferredCaptureInterface = function (interfaces) {
            var monitor = interfaces.find(function (iface) { return /mon$/i.test(iface); });
            if (monitor) {
                return monitor;
            }
            var external = interfaces.find(function (iface) { return /^wlan[1-9]/i.test(iface); });
            return external || interfaces[0];
        };
        PineReconComponent.prototype.checkScanStatus = function () {
            var _this = this;
            this.API.APIGet('/api/recon/status', function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.scanning = false;
                    _this.loading = false;
                    clearInterval(_this.poller);
                    _this.poller = null;
                    return;
                }
                var running = response && (response.scanRunning || response.continuous || response.running || response.scanning);
                _this.scanPercent = response && response.scanPercent !== undefined ? response.scanPercent : _this.scanPercent;
                if (response && (response.scanID || response.scan_id)) {
                    _this.scanId = (response.scanID || response.scan_id).toString();
                }
                _this.loadRecon(_this.scanId);
                if (!running) {
                    _this.scanning = false;
                    _this.loading = false;
                    _this.notifyScan('stop', 0);
                    clearInterval(_this.poller);
                    _this.poller = null;
                }
            });
        };
        PineReconComponent.prototype.pollDependencyJob = function (jobId) {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'poll_job', job_id: jobId, remove_if_complete: false }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.dependencyBusy = false;
                    return;
                }
                if (response.is_complete) {
                    _this.dependencyBusy = false;
                    _this.loadStatus();
                    _this.checkDependencies();
                    return;
                }
                setTimeout(function () { return _this.pollDependencyJob(jobId); }, 2500);
            });
        };
        PineReconComponent.prototype.pollCaptureJob = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'poll_job', job_id: this.captureJobId, remove_if_complete: false }, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.capturing = false;
                    _this.loadCaptures();
                    return;
                }
                if (response.log_tail) {
                    _this.handshakeLog = response.log_tail;
                }
                if (response.is_complete) {
                    _this.capturing = false;
                    _this.captureStartedAt = 0;
                    _this.captureJobId = '';
                    if (response.job_error) {
                        _this.error = response.job_error;
                    }
                    if (response.result) {
                        _this.activeCapture = response.result;
                        _this.selectedCapture = response.result;
                        _this.selectedCaptureFile = response.result.file || _this.selectedCaptureFile;
                    }
                    if (response.result && response.result.log_tail) {
                        _this.handshakeLog = response.result.log_tail;
                    }
                    _this.loadCaptures();
                    return;
                }
                _this.loadHandshakeStatus();
                setTimeout(function () { return _this.pollCaptureJob(); }, 3000);
            });
        };
        PineReconComponent.prototype.loadHandshakeStatus = function () {
            var _this = this;
            if (!this.captureJobId) {
                return;
            }
            this.API.request({ module: 'PineRecon', action: 'handshake_status', job_id: this.captureJobId }, function (response) {
                if (response && !response.error) {
                    _this.activeCapture = Object.assign(_this.activeCapture || _this.emptyCaptureReport(response.output_file || response.file || 'running-capture'), response);
                    if (response.log_tail) {
                        _this.handshakeLog = response.log_tail;
                    }
                }
            });
        };
        PineReconComponent.prototype.loadRecon = function (scanId) {
            var _this = this;
            if (scanId) {
                this.loadReconScan(scanId);
                return;
            }
            this.API.APIGet('/api/recon/scans', function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.loading = false;
                    return;
                }
                var scans = _this.normaliseArray(response);
                if (!scans.length) {
                    _this.accessPoints = [];
                    _this.clients = [];
                    _this.updateStats([]);
                    _this.loading = false;
                    return;
                }
                var latest = scans[0];
                var latestId = (latest.scan_id || latest.scanID || latest.id || '').toString();
                if (!latestId) {
                    _this.loading = false;
                    return;
                }
                _this.loadReconScan(latestId);
            });
        };
        PineReconComponent.prototype.loadReconScan = function (scanId) {
            var _this = this;
            this.API.APIGet("/api/recon/scans/" + scanId, function (response) {
                if (response && response.error) {
                    _this.error = response.error;
                    _this.loading = false;
                    return;
                }
                var aps = _this.extractAccessPoints(response);
                _this.accessPoints = aps;
                _this.clients = _this.extractClientRecords(response, aps);
                _this.updateStats(aps);
                _this.pageIndex = Math.min(_this.pageIndex, _this.apPageCount - 1);
                _this.clientPageIndex = Math.min(_this.clientPageIndex, _this.clientPageCount - 1);
                if (!_this.selectedAp && aps.length) {
                    _this.selectedAp = aps[0];
                }
                _this.scanId = scanId;
                _this.lastUpdated = new Date().toLocaleTimeString();
                _this.loading = false;
                _this.enrichVendors(aps);
            });
        };
        PineReconComponent.prototype.loadCaptures = function () {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'list_captures' }, function (response) {
                if (response && !response.error) {
                    _this.captures = response;
                    if (_this.selectedCapture) {
                        _this.selectedCapture = _this.captures.find(function (capture) { return capture.file === _this.selectedCapture.file; }) || null;
                    }
                    if (!_this.selectedCapture && _this.captures.length) {
                        _this.selectedCapture = _this.captures[0];
                    }
                    if (!_this.capturing) {
                        _this.activeCapture = null;
                    }
                    _this.selectedCaptureFile = _this.selectedCapture ? _this.selectedCapture.file : '';
                }
            });
        };
        PineReconComponent.prototype.enrichVendors = function (aps) {
            var _this = this;
            this.API.request({ module: 'PineRecon', action: 'enrich_aps', aps: aps }, function (response) {
                if (!response || response.error || !response.vendors) {
                    return;
                }
                var vendors = response.vendors;
                _this.accessPoints = _this.accessPoints.map(function (ap) {
                    var normalized = (ap.bssid || '').replace(/[^A-Fa-f0-9]/g, '').toUpperCase();
                    ap.vendor = vendors[ap.bssid] || vendors[(ap.bssid || '').toUpperCase()] || vendors[normalized] || ap.vendor || 'Unknown';
                    return ap;
                });
            });
        };
        PineReconComponent.prototype.updateStats = function (aps) {
            this.channelStats = this.makeBuckets(aps.map(function (ap) { return ap.channel || 'N/A'; }));
            this.securityStats = this.makeBuckets(aps.map(function (ap) { return ap.security || 'Open'; }));
        };
        PineReconComponent.prototype.makeBuckets = function (values) {
            var total = values.length || 1;
            var counts = values.reduce(function (acc, value) {
                acc[value] = (acc[value] || 0) + 1;
                return acc;
            }, {});
            return Object.keys(counts).map(function (label) { return ({
                label: label,
                count: counts[label],
                percent: Math.round((counts[label] / total) * 100)
            }); }).sort(function (a, b) { return b.count - a.count; });
        };
        PineReconComponent.prototype.extractAccessPoints = function (response) {
            var _this = this;
            var scans = this.normaliseArray(response);
            var latest = scans.length ? scans[0] : response;
            var rawAps = this.normaliseArray(latest && (latest.APResults || latest.ap_results || latest.access_points || latest.aps));
            return rawAps.map(function (ap, index) { return _this.mapAccessPoint(ap, index); })
                .sort(function (a, b) { return b.signal - a.signal; });
        };
        PineReconComponent.prototype.extractClientRecords = function (response, aps) {
            var _this = this;
            var byBssid = aps.reduce(function (acc, ap) {
                acc[(ap.bssid || '').toUpperCase()] = ap;
                return acc;
            }, {});
            var latest = Array.isArray(response) ? response[0] : response;
            var records = [];
            aps.forEach(function (ap) {
                var rawAp = _this.findRawAp(latest, ap.bssid);
                _this.normaliseArray(rawAp && rawAp.clients).forEach(function (client) {
                    records.push(_this.mapClient(client, ap, true));
                });
            });
            var outOfRange = this.normaliseArray(latest && (latest.OutOfRangeClientResults || latest.OutOfRangeResult || latest.out_of_range_clients));
            var unassociated = this.normaliseArray(latest && (latest.UnassociatedClientResults || latest.UnassociatedResult || latest.unassociated_clients));
            outOfRange.concat(unassociated).forEach(function (client) {
                var ap = byBssid[(client.ap_mac || client.ap_bssid || '').toUpperCase()];
                records.push(_this.mapClient(client, ap, !!ap));
            });
            return records.sort(function (a, b) { return b.dataFrames - a.dataFrames; });
        };
        PineReconComponent.prototype.findRawAp = function (response, bssid) {
            var rawAps = this.normaliseArray(response && (response.APResults || response.ap_results || response.access_points || response.aps));
            return rawAps.find(function (ap) { return (ap.bssid || ap.BSSID || '').toUpperCase() === (bssid || '').toUpperCase(); });
        };
        PineReconComponent.prototype.mapClient = function (client, ap, associated) {
            return {
                mac: typeof client === 'string' ? client : (client.client_mac || client.mac || client.client || ''),
                apBssid: ap ? ap.bssid : (client.ap_mac || client.ap_bssid || 'Unassociated'),
                apSsid: ap ? ap.ssid : 'Unassociated',
                apChannel: ap ? ap.channel : (client.ap_channel || 'N/A').toString(),
                security: ap ? ap.security : 'N/A',
                mfp: ap ? ap.mfp : 'Unknown',
                dataFrames: parseInt(client.data || '0', 10) || 0,
                broadcastProbes: parseInt(client.broadcast_probes || '0', 10) || 0,
                directProbes: parseInt(client.direct_probes || '0', 10) || 0,
                lastSeen: client.last_seen || 'N/A',
                associated: associated
            };
        };
        PineReconComponent.prototype.normaliseArray = function (value) {
            if (!value) {
                return [];
            }
            if (Array.isArray(value)) {
                return value;
            }
            if (value.scans && Array.isArray(value.scans)) {
                return value.scans;
            }
            if (value.data && Array.isArray(value.data)) {
                return value.data;
            }
            return [];
        };
        PineReconComponent.prototype.mapAccessPoint = function (ap, index) {
            var signal = parseInt(ap.signal || ap.rssi || ap.power || '-95', 10);
            var channel = (ap.channel || ap.chan || '').toString();
            var securityTags = this.securityTags(ap.encryption !== undefined ? ap.encryption : ap.security || ap.privacy);
            var clientList = this.extractClients(ap);
            var radians = ((index * 47) % 360) * (Math.PI / 180);
            var radius = 18 + (100 - this.signalPercent(signal)) * 0.28;
            return {
                bssid: ap.bssid || ap.BSSID || '',
                ssid: ap.ssid || ap.SSID || '<hidden>',
                channel: channel,
                signal: signal,
                security: securityTags.join(' / ') || 'Open',
                securityTags: securityTags,
                hidden: !!ap.hidden,
                wps: !!ap.wps,
                lastSeen: ap.last_seen || ap.lastSeen || 'N/A',
                dataFrames: parseInt(ap.data || '0', 10) || 0,
                probes: parseInt(ap.probes || '0', 10) || 0,
                clients: clientList.length || parseInt(ap.clients || ap.client_count || '0', 10) || 0,
                clientList: clientList,
                vendor: 'Lookup pending',
                mfp: this.mfpState(ap),
                securityDetails: this.securityDetails(ap, securityTags),
                taggedParameters: this.taggedParameters(ap),
                x: 50 + Math.cos(radians) * radius,
                y: 50 + Math.sin(radians) * radius,
                delay: (index % 8) * 0.18
            };
        };
        PineReconComponent.prototype.securityDetails = function (ap, securityTags) {
            var authentication = this.valueList(ap.akm_suites || ap.akms || ap.auth_key_suites || ap.authentication_key_suites ||
                ap.authentication || ap.auth || ap.key_management || ap.keyManagement);
            var groupCiphers = this.valueList(ap.group_cipher_suites || ap.group_ciphers || ap.group_cipher || ap.groupCipher ||
                ap.group || ap.cipher);
            var pairwiseCiphers = this.valueList(ap.pairwise_cipher_suites || ap.pairwise_ciphers || ap.pairwise_cipher ||
                ap.pairwiseCipher || ap.pairwise || ap.ciphers);
            var ssid = ap.ssid || ap.SSID || '<hidden>';
            var bssid = ap.bssid || ap.BSSID || '';
            var security = securityTags.join(' and ') || 'Open';
            var authText = authentication.length ? authentication.join(', ') : 'unknown';
            var pairwiseText = pairwiseCiphers.length ? pairwiseCiphers.join(', ') : 'unknown';
            var groupText = groupCiphers.length ? groupCiphers.join(', ') : 'unknown';
            return {
                summary: ssid + " (" + bssid + ") is using " + security + " security with " + authText + " authentication key suites, " + pairwiseText + " pairwise ciphers, and " + groupText + " group ciphers.",
                authentication: authentication,
                groupCiphers: groupCiphers,
                pairwiseCiphers: pairwiseCiphers
            };
        };
        PineReconComponent.prototype.taggedParameters = function (ap) {
            var raw = ap.tagged_parameters || ap.taggedParameters || ap.information_elements ||
                ap.informationElements || ap.InformationElements || ap.ies || ap.IEs || ap.ie;
            var items = this.normaliseObjectList(raw);
            return items.map(function (item, index) {
                if (typeof item === 'string' || typeof item === 'number') {
                    return { name: "Tag " + (index + 1), value: item.toString() };
                }
                var name = item.name || item.tag || item.id || item.type || item.element || "Tag " + (index + 1);
                var value = item.value || item.data || item.info || item.description || item.raw || item.hex || JSON.stringify(item);
                return { name: name.toString(), value: value.toString() };
            }).filter(function (item) { return item.name || item.value; });
        };
        PineReconComponent.prototype.normaliseObjectList = function (value) {
            if (!value) {
                return [];
            }
            if (Array.isArray(value)) {
                return value;
            }
            if (typeof value === 'object') {
                return Object.keys(value).map(function (key) {
                    var item = value[key];
                    if (typeof item === 'object') {
                        return Object.assign({ name: key }, item);
                    }
                    return { name: key, value: item };
                });
            }
            return [value];
        };
        PineReconComponent.prototype.valueList = function (value) {
            if (!value) {
                return [];
            }
            if (Array.isArray(value)) {
                return value.map(function (item) { return item.toString(); }).filter(function (item) { return item; });
            }
            if (typeof value === 'object') {
                return Object.keys(value).map(function (key) { return value[key] === true ? key : value[key].toString(); }).filter(function (item) { return item; });
            }
            return value.toString().split(/[,+/|;]/).map(function (item) { return item.trim(); }).filter(function (item) { return item; });
        };
        PineReconComponent.prototype.extractClients = function (ap) {
            var clients = ap.clients || ap.Clients || ap.client_macs || [];
            if (!Array.isArray(clients)) {
                return [];
            }
            return clients.map(function (client) {
                if (typeof client === 'string') {
                    return client;
                }
                return client.client_mac || client.mac || client.client || client.station || client.bssid || '';
            }).filter(function (client) { return client; });
        };
        PineReconComponent.prototype.securityTags = function (encryption) {
            if (typeof encryption === 'string') {
                return encryption.split(/[,+/ ]+/).filter(function (tag) { return tag; });
            }
            var value = parseInt(encryption || '0', 10);
            if (!value) {
                return ['Open'];
            }
            var tags = [];
            if (value & 1) {
                tags.push('WEP');
            }
            if (value & 2) {
                tags.push('WPA');
            }
            if (value & 4) {
                tags.push('WPA2');
            }
            if (value & 8) {
                tags.push('WPA3');
            }
            return tags.length ? tags : ["Enc " + value];
        };
        PineReconComponent.prototype.mfpState = function (ap) {
            var value = ap.mfp !== undefined ? ap.mfp :
                ap.MFP !== undefined ? ap.MFP :
                    ap.pmf !== undefined ? ap.pmf :
                        ap.PMF !== undefined ? ap.PMF :
                            ap.management_frame_protection !== undefined ? ap.management_frame_protection :
                                ap.managementFrameProtection !== undefined ? ap.managementFrameProtection :
                                    ap.ieee80211w !== undefined ? ap.ieee80211w :
                                        ap.pmf_required !== undefined ? ap.pmf_required :
                                            ap.mfp_required;
            if (value === undefined || value === null || value === '') {
                return 'Unknown';
            }
            if (typeof value === 'boolean') {
                return value ? 'Enabled' : 'Disabled';
            }
            var text = value.toString().trim().toLowerCase();
            if (text === '2' || text.indexOf('required') !== -1) {
                return 'Required';
            }
            if (text === '1' || text.indexOf('capable') !== -1 || text.indexOf('enabled') !== -1 || text === 'true') {
                return 'Enabled';
            }
            if (text === '0' || text.indexOf('disabled') !== -1 || text === 'false') {
                return 'Disabled';
            }
            return value.toString();
        };
        Object.defineProperty(PineReconComponent.prototype, "themeClass", {
            get: function () {
                return this.theme + "-theme";
            },
            enumerable: true,
            configurable: true
        });
        PineReconComponent.ctorParameters = function () { return [
            { type: ApiService }
        ]; };
        PineReconComponent = __decorate([
            core.Component({
                selector: 'lib-PineRecon',
                template: "<section class=\"pinerecon-shell\" [ngClass]=\"themeClass\">\n    <header class=\"command-bar\">\n        <div class=\"brand-lockup\">\n            <img *ngIf=\"!logoFailed\" [src]=\"logoPath\" alt=\"\" (error)=\"onLogoError()\">\n            <strong *ngIf=\"logoFailed\">PineRecon</strong>\n            <p class=\"eyebrow\">WiFi Pineapple Recon</p>\n        </div>\n\n        <div class=\"actions\">\n            <div class=\"control-cluster\">\n                <span>Band</span>\n                <mat-button-toggle-group [(ngModel)]=\"band\" aria-label=\"Recon band\">\n                    <mat-button-toggle value=\"both\">Dual</mat-button-toggle>\n                    <mat-button-toggle value=\"2.4\">2.4</mat-button-toggle>\n                    <mat-button-toggle value=\"5\">5</mat-button-toggle>\n                </mat-button-toggle-group>\n            </div>\n\n            <div class=\"control-cluster theme-cluster\">\n                <span>Theme</span>\n                <mat-form-field appearance=\"outline\">\n                    <mat-select [ngModel]=\"theme\" (ngModelChange)=\"onThemeChange($event)\" aria-label=\"PineRecon theme\">\n                        <mat-option *ngFor=\"let option of themes\" [value]=\"option.value\">{{ option.label }}</mat-option>\n                    </mat-select>\n                </mat-form-field>\n            </div>\n\n            <div class=\"control-cluster scan-time\">\n                <span>Scan Time</span>\n                <mat-button-toggle-group [(ngModel)]=\"scanTime\" aria-label=\"Scan time\">\n                    <mat-button-toggle [value]=\"10\">10s</mat-button-toggle>\n                    <mat-button-toggle [value]=\"15\">15s</mat-button-toggle>\n                    <mat-button-toggle [value]=\"30\">30s</mat-button-toggle>\n                    <mat-button-toggle [value]=\"60\">60s</mat-button-toggle>\n                </mat-button-toggle-group>\n            </div>\n\n            <button class=\"primary-action\" mat-raised-button color=\"primary\" (click)=\"startScan()\" [disabled]=\"scanning\">\n                <mat-icon>settings_input_antenna</mat-icon>\n                Scan\n            </button>\n            <button class=\"primary-action ghost-action\" mat-raised-button (click)=\"startIndefiniteScan()\" [disabled]=\"scanning\">\n                <mat-icon>all_inclusive</mat-icon>\n                Indefinite\n            </button>\n            <button class=\"danger-action\" mat-raised-button (click)=\"stopScan()\" [disabled]=\"!scanning\">\n                <mat-icon>stop</mat-icon>\n                Stop Scan\n            </button>\n            <button class=\"ghost-action\" mat-raised-button (click)=\"downloadLogs()\">\n                <mat-icon>file_download</mat-icon>\n                Logs\n            </button>\n            <button mat-icon-button matTooltip=\"Refresh\" (click)=\"refresh()\">\n                <mat-icon>refresh</mat-icon>\n            </button>\n        </div>\n    </header>\n\n    <div class=\"status-strip\">\n        <div class=\"status-pill\" [class.good]=\"status.internet\">\n            <mat-icon>public</mat-icon>\n            <span>{{ status.internet ? 'Online' : 'Offline' }}</span>\n        </div>\n        <div class=\"status-pill\">\n            <mat-icon>hub</mat-icon>\n            <span>{{ status.socket }}</span>\n        </div>\n        <div class=\"status-pill\">\n            <mat-icon>wifi_tethering</mat-icon>\n            <span>{{ accessPoints.length }} APs</span>\n        </div>\n        <div class=\"status-pill\">\n            <mat-icon>groups</mat-icon>\n            <span>{{ clients.length }} Clients</span>\n        </div>\n        <div class=\"status-pill\">\n            <mat-icon>fingerprint</mat-icon>\n            <span>{{ status.oui_count }} OUIs</span>\n        </div>\n        <div class=\"status-pill\" [class.good]=\"captureReady()\">\n            <mat-icon>verified</mat-icon>\n            <span>{{ captureReady() ? captureEngineLabel() : 'Deps needed' }}</span>\n        </div>\n        <div class=\"status-pill muted\" *ngIf=\"lastUpdated\">\n            <mat-icon>schedule</mat-icon>\n            <span>{{ lastUpdated }}</span>\n        </div>\n        <div class=\"status-pill muted\" *ngIf=\"scanId\">\n            <mat-icon>tag</mat-icon>\n            <span>Scan {{ scanId }} / {{ continuousScan ? 'continuous' : scanPercent + '%' }}</span>\n        </div>\n    </div>\n\n    <div class=\"load-stage\" *ngIf=\"loading || scanning || capturing || dependencyBusy\">\n        <div class=\"scan-loader\">\n            <span></span>\n            <span></span>\n            <span></span>\n        </div>\n        <strong *ngIf=\"scanning\">Recon sweep in progress</strong>\n        <strong *ngIf=\"capturing\">Handshake capture armed</strong>\n        <strong *ngIf=\"dependencyBusy\">Installing PineRecon tooling</strong>\n        <strong *ngIf=\"loading && !scanning && !capturing && !dependencyBusy\">Synchronizing telemetry</strong>\n    </div>\n    <mat-progress-bar *ngIf=\"loading || scanning || capturing || dependencyBusy\" mode=\"indeterminate\"></mat-progress-bar>\n    <div class=\"error\" *ngIf=\"error\">{{ error }}</div>\n\n    <div class=\"dependency-banner\" *ngIf=\"(dependencyChecked && !captureReady()) || (ouiChecked && !status.oui_count)\">\n        <div>\n            <strong>{{ dependencyChecked && !captureReady() ? 'Capture tooling unavailable' : 'OUI database not loaded' }}</strong>\n            <span *ngIf=\"dependencyChecked && !captureReady()\">Install {{ (status.dependency_packages || ['hcxdumptool', 'aircrack-ng']).join(', ') }} only if this Pineapple does not already provide hcxdumptool or airodump-ng.</span>\n            <span *ngIf=\"ouiChecked && (!dependencyChecked || captureReady()) && !status.oui_count\">{{ status.oui_error || 'No Pineapple OUI database was found by the module backend.' }}</span>\n            <small *ngIf=\"status.oui_path\">OUI source: {{ status.oui_path }}</small>\n        </div>\n        <button *ngIf=\"dependencyChecked && !captureReady()\" class=\"install-cta\" mat-raised-button (click)=\"installDependencies()\" [disabled]=\"dependencyBusy\">\n            <mat-icon>file_download</mat-icon>\n            Install Dependencies\n        </button>\n        <button *ngIf=\"ouiChecked && (!dependencyChecked || captureReady()) && !status.oui_count\" class=\"ghost-action\" mat-raised-button (click)=\"reloadOuis()\">\n            <mat-icon>refresh</mat-icon>\n            Recheck\n        </button>\n    </div>\n\n    <main class=\"recon-grid\" *ngIf=\"!loading || accessPoints.length\">\n        <section class=\"radar-panel\">\n            <div class=\"radar\">\n                <div class=\"ring ring-one\"></div>\n                <div class=\"ring ring-two\"></div>\n                <div class=\"ring ring-three\"></div>\n                <div class=\"sweep\"></div>\n                <div class=\"origin\">\n                    <mat-icon>router</mat-icon>\n                </div>\n\n                <button\n                    type=\"button\"\n                    class=\"target\"\n                    *ngFor=\"let ap of accessPoints; trackBy: trackByBssid\"\n                    [class.selected]=\"selectedAp === ap\"\n                    [style.left.%]=\"ap.x\"\n                    [style.top.%]=\"ap.y\"\n                    [style.animation-delay.s]=\"ap.delay\"\n                    (click)=\"selectAp(ap)\"\n                    [matTooltip]=\"ap.ssid + ' / ' + ap.bssid\">\n                    <span></span>\n                </button>\n            </div>\n\n            <aside class=\"focus-panel\" *ngIf=\"selectedAp\">\n                <div>\n                    <p class=\"eyebrow\">Target lock</p>\n                    <h2>{{ selectedAp.ssid }}</h2>\n                    <p>{{ selectedAp.bssid }}</p>\n                </div>\n                <div class=\"focus-bars\">\n                    <span *ngFor=\"let bar of signalBars(selectedAp.signal)\" [class.on]=\"bar\"></span>\n                    <strong>{{ selectedAp.signal }} dBm</strong>\n                </div>\n                <div class=\"focus-meta\">\n                    <span>CH {{ selectedAp.channel || 'N/A' }}</span>\n                    <span *ngFor=\"let tag of selectedAp.securityTags\">{{ tag }}</span>\n                    <span>{{ selectedAp.vendor }}</span>\n                    <span>MFP {{ selectedAp.mfp }}</span>\n                    <span>{{ selectedAp.clients }} clients</span>\n                    <span *ngIf=\"selectedAp.hidden\">Hidden</span>\n                    <span *ngIf=\"selectedAp.wps\">WPS</span>\n                </div>\n\n                <div class=\"client-list\" *ngIf=\"selectedAp.clientList.length\">\n                    <span *ngFor=\"let client of selectedAp.clientList\">{{ client }}</span>\n                </div>\n\n                <div class=\"ap-detail-tools\">\n                    <button type=\"button\" mat-raised-button [class.active]=\"selectedApDetail === 'security'\" (click)=\"selectedApDetail = 'security'\">\n                        <mat-icon>security</mat-icon>\n                        Security Info\n                    </button>\n                    <button type=\"button\" mat-raised-button [class.active]=\"selectedApDetail === 'tags'\" (click)=\"selectedApDetail = 'tags'\">\n                        <mat-icon>sell</mat-icon>\n                        Tagged Params\n                    </button>\n                </div>\n\n                <div class=\"ap-detail-panel\" *ngIf=\"selectedApDetail === 'security'\">\n                    <strong>Security Information for {{ selectedAp.ssid }} ({{ selectedAp.bssid }})</strong>\n                    <p>{{ selectedAp.securityDetails.summary }}</p>\n                    <div class=\"detail-list\">\n                        <span><b>Authentication Key Suites:</b> {{ selectedAp.securityDetails.authentication.length ? selectedAp.securityDetails.authentication.join(', ') : selectedAp.security }}</span>\n                        <span><b>Group Cipher Suites:</b> {{ selectedAp.securityDetails.groupCiphers.length ? selectedAp.securityDetails.groupCiphers.join(', ') : 'Not reported' }}</span>\n                        <span><b>Pairwise Cipher Suites:</b> {{ selectedAp.securityDetails.pairwiseCiphers.length ? selectedAp.securityDetails.pairwiseCiphers.join(', ') : 'Not reported' }}</span>\n                        <span><b>MFP/PMF:</b> {{ selectedAp.mfp }}</span>\n                    </div>\n                </div>\n\n                <div class=\"ap-detail-panel\" *ngIf=\"selectedApDetail === 'tags'\">\n                    <strong>Tagged Parameters for {{ selectedAp.ssid }} ({{ selectedAp.bssid }})</strong>\n                    <p>This table contains tagged parameters, also known as Information Elements, seen in frames transmitted from this AP.</p>\n                    <div class=\"tagged-table\" *ngIf=\"hasTaggedParameters(selectedAp)\">\n                        <div class=\"tagged-row header\">\n                            <span>Parameter</span>\n                            <span>Value</span>\n                        </div>\n                        <div class=\"tagged-row\" *ngFor=\"let parameter of selectedAp.taggedParameters\">\n                            <span>{{ parameter.name }}</span>\n                            <span>{{ parameter.value }}</span>\n                        </div>\n                    </div>\n                    <div class=\"detail-list\" *ngIf=\"!hasTaggedParameters(selectedAp)\">\n                        <span>No tagged parameters were included in this recon result.</span>\n                    </div>\n                </div>\n\n                <div class=\"intel-grid\">\n                    <button type=\"button\" class=\"intel-card\">\n                        <mat-icon>security</mat-icon>\n                        <strong>Security</strong>\n                        <span>{{ selectedAp.security }}</span>\n                    </button>\n                    <button type=\"button\" class=\"intel-card\">\n                        <mat-icon>groups</mat-icon>\n                        <strong>Clients</strong>\n                        <span>{{ selectedAp.clients }} seen</span>\n                    </button>\n                    <button type=\"button\" class=\"intel-card\">\n                        <mat-icon>data_usage</mat-icon>\n                        <strong>Traffic</strong>\n                        <span>{{ selectedAp.dataFrames }} data / {{ selectedAp.probes }} probes</span>\n                    </button>\n                    <button type=\"button\" class=\"intel-card\">\n                        <mat-icon>vpn_key</mat-icon>\n                        <strong>Handshake</strong>\n                        <span>{{ selectedCapture ? selectedCapture.confidence : 'none' }}</span>\n                    </button>\n                    <button type=\"button\" class=\"intel-card\">\n                        <mat-icon>admin_panel_settings</mat-icon>\n                        <strong>MFP/PMF</strong>\n                        <span>{{ selectedAp.mfp }}</span>\n                    </button>\n                </div>\n\n                <div class=\"capture-controls\">\n                    <button class=\"handshake-cta\" mat-raised-button (click)=\"startHandshakeCapture()\" [disabled]=\"capturing || !captureReady()\">\n                        <mat-icon>vpn_key</mat-icon>\n                        Start Handshake\n                    </button>\n                    <mat-form-field class=\"capture-select interface-select\" appearance=\"outline\">\n                        <mat-label>Interface</mat-label>\n                        <mat-select [(ngModel)]=\"captureInterface\" (selectionChange)=\"runHandshakePreflight()\" aria-label=\"Handshake capture interface\">\n                            <mat-option *ngFor=\"let iface of status.interfaces\" [value]=\"iface\">{{ iface }}</mat-option>\n                        </mat-select>\n                    </mat-form-field>\n                    <mat-form-field class=\"capture-select duration-select\" appearance=\"outline\">\n                        <mat-label>Duration</mat-label>\n                        <mat-select [(ngModel)]=\"captureDuration\" aria-label=\"Handshake capture duration\">\n                            <mat-option [value]=\"0\">Indefinite</mat-option>\n                            <mat-option [value]=\"60\">60s</mat-option>\n                            <mat-option [value]=\"90\">90s</mat-option>\n                            <mat-option [value]=\"180\">180s</mat-option>\n                            <mat-option [value]=\"300\">300s</mat-option>\n                        </mat-select>\n                    </mat-form-field>\n                    <button class=\"danger-action\" mat-raised-button (click)=\"stopHandshakeCapture()\" [disabled]=\"!capturing\">\n                        <mat-icon>stop_circle</mat-icon>\n                        Stop\n                    </button>\n                </div>\n\n                <div class=\"preflight-panel\" *ngIf=\"handshakePreflight\">\n                    <div>\n                        <strong>{{ handshakePreflight.ready ? 'Capture preflight ready' : 'Capture preflight needs attention' }}</strong>\n                        <span>{{ handshakePreflight.capture_engine || captureEngineLabel() }} / {{ captureInterface || 'No interface' }}</span>\n                    </div>\n                    <small *ngIf=\"handshakePreflight.interface_info\">\n                        Mode {{ handshakePreflight.interface_info.type || 'unknown' }} /\n                        CH {{ handshakePreflight.interface_info.channel || 'unknown' }}\n                    </small>\n                    <ul *ngIf=\"handshakePreflight.blockers && handshakePreflight.blockers.length\">\n                        <li *ngFor=\"let blocker of handshakePreflight.blockers\">{{ blocker }}</li>\n                    </ul>\n                    <ul *ngIf=\"handshakePreflight.warnings && handshakePreflight.warnings.length\">\n                        <li *ngFor=\"let warning of handshakePreflight.warnings\">{{ warning }}</li>\n                    </ul>\n                    <small *ngIf=\"handshakePreflight.suggestions && handshakePreflight.suggestions.length\">\n                        {{ handshakePreflight.suggestions.join(' ') }}\n                    </small>\n                </div>\n\n            </aside>\n        </section>\n\n        <section class=\"data-panel\">\n            <mat-tab-group>\n                <mat-tab label=\"Access Points\">\n                    <div class=\"analysis-strip\">\n                        <div class=\"analysis-block\">\n                            <div class=\"analysis-title\">\n                                <mat-icon>settings_input_component</mat-icon>\n                                <span>Channel Distribution</span>\n                            </div>\n                            <div class=\"stat-row\" *ngFor=\"let stat of channelStats\">\n                                <strong>CH {{ stat.label }}</strong>\n                                <div class=\"stat-track\">\n                                    <span [style.width.%]=\"stat.percent\"></span>\n                                </div>\n                                <em>{{ stat.count }}</em>\n                            </div>\n                        </div>\n\n                        <div class=\"analysis-block\">\n                            <div class=\"analysis-title\">\n                                <mat-icon>enhanced_encryption</mat-icon>\n                                <span>Security Distribution</span>\n                            </div>\n                            <div class=\"stat-row\" *ngFor=\"let stat of securityStats\">\n                                <strong>{{ stat.label }}</strong>\n                                <div class=\"stat-track\">\n                                    <span [style.width.%]=\"stat.percent\"></span>\n                                </div>\n                                <em>{{ stat.percent }}%</em>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"table-panel\">\n                        <table mat-table [dataSource]=\"pagedAccessPoints\" class=\"ap-table\">\n                            <ng-container matColumnDef=\"signal\">\n                                <th mat-header-cell *matHeaderCellDef>Signal</th>\n                                <td mat-cell *matCellDef=\"let ap\">\n                                    <div class=\"bars\">\n                                        <span *ngFor=\"let bar of signalBars(ap.signal)\" [class.on]=\"bar\"></span>\n                                    </div>\n                                    <small>{{ ap.signal }} dBm</small>\n                                </td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"ssid\">\n                                <th mat-header-cell *matHeaderCellDef>SSID</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.ssid }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"bssid\">\n                                <th mat-header-cell *matHeaderCellDef>BSSID</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.bssid }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"vendor\">\n                                <th mat-header-cell *matHeaderCellDef>OUI</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.vendor }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"channel\">\n                                <th mat-header-cell *matHeaderCellDef>CH</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.channel || 'N/A' }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"security\">\n                                <th mat-header-cell *matHeaderCellDef>Security</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.security }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"wps\">\n                                <th mat-header-cell *matHeaderCellDef>WPS</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.wps ? 'Enabled' : 'Disabled' }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"mfp\">\n                                <th mat-header-cell *matHeaderCellDef>MFP</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.mfp }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"clients\">\n                                <th mat-header-cell *matHeaderCellDef>Clients</th>\n                                <td mat-cell *matCellDef=\"let ap\">{{ ap.clients }}</td>\n                            </ng-container>\n\n                            <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n                            <tr\n                                mat-row\n                                *matRowDef=\"let row; columns: displayedColumns;\"\n                                [class.selected]=\"selectedAp === row\"\n                                (click)=\"selectAp(row)\">\n                            </tr>\n                        </table>\n\n                        <div class=\"empty-state\" *ngIf=\"!accessPoints.length && !loading\">\n                            <mat-icon>wifi_find</mat-icon>\n                            <span>No recon captures loaded</span>\n                        </div>\n                    </div>\n                    <div class=\"pager-row\" *ngIf=\"accessPoints.length\">\n                        <button mat-button (click)=\"prevApPage()\" [disabled]=\"pageIndex === 0\">\n                            <mat-icon>chevron_left</mat-icon>\n                            Previous\n                        </button>\n                        <span>Showing {{ pageIndex * pageSize + 1 }}-{{ pageIndex * pageSize + pagedAccessPoints.length }} of {{ accessPoints.length }}</span>\n                        <button mat-button (click)=\"nextApPage()\" [disabled]=\"pageIndex >= apPageCount - 1\">\n                            Next\n                            <mat-icon>chevron_right</mat-icon>\n                        </button>\n                    </div>\n                </mat-tab>\n\n                <mat-tab label=\"Clients ({{ clients.length }})\">\n                    <div class=\"client-detail\" *ngIf=\"selectedClient\">\n                        <div>\n                            <p class=\"eyebrow\">Selected Client</p>\n                            <h3>{{ selectedClient.mac }}</h3>\n                            <span>{{ selectedClient.associated ? 'Associated' : 'Unassociated' }}</span>\n                        </div>\n                        <div class=\"client-detail-grid\">\n                            <span><strong>AP</strong>{{ selectedClient.apSsid }}</span>\n                            <span><strong>BSSID</strong>{{ selectedClient.apBssid }}</span>\n                            <span><strong>Security</strong>{{ selectedClient.security }}</span>\n                            <span><strong>MFP/PMF</strong>{{ selectedClient.mfp }}</span>\n                            <span><strong>Channel</strong>{{ selectedClient.apChannel }}</span>\n                            <span><strong>Frames</strong>{{ selectedClient.dataFrames }}</span>\n                            <span><strong>Last Seen</strong>{{ selectedClient.lastSeen }}</span>\n                        </div>\n                        <button class=\"handshake-cta\" mat-raised-button (click)=\"startClientHandshake()\" [disabled]=\"capturing || !selectedClient.associated || !captureReady()\">\n                            <mat-icon>vpn_key</mat-icon>\n                            Target AP Handshake\n                        </button>\n                    </div>\n\n                    <div class=\"table-panel\">\n                        <table mat-table [dataSource]=\"pagedClients\" class=\"ap-table client-table\">\n                            <ng-container matColumnDef=\"mac\">\n                                <th mat-header-cell *matHeaderCellDef>Client</th>\n                                <td mat-cell *matCellDef=\"let client\">{{ client.mac }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"ap\">\n                                <th mat-header-cell *matHeaderCellDef>Access Point</th>\n                                <td mat-cell *matCellDef=\"let client\">\n                                    <strong>{{ client.apSsid }}</strong>\n                                    <small>{{ client.apBssid }}</small>\n                                </td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"security\">\n                                <th mat-header-cell *matHeaderCellDef>Security</th>\n                                <td mat-cell *matCellDef=\"let client\">{{ client.security }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"channel\">\n                                <th mat-header-cell *matHeaderCellDef>CH</th>\n                                <td mat-cell *matCellDef=\"let client\">{{ client.apChannel }}</td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"data\">\n                                <th mat-header-cell *matHeaderCellDef>Frames</th>\n                                <td mat-cell *matCellDef=\"let client\">\n                                    {{ client.dataFrames }}\n                                    <small>{{ client.broadcastProbes }} broadcast / {{ client.directProbes }} direct probes</small>\n                                </td>\n                            </ng-container>\n\n                            <ng-container matColumnDef=\"lastSeen\">\n                                <th mat-header-cell *matHeaderCellDef>Last Seen</th>\n                                <td mat-cell *matCellDef=\"let client\">{{ client.lastSeen }}</td>\n                            </ng-container>\n\n                            <tr mat-header-row *matHeaderRowDef=\"clientColumns\"></tr>\n                            <tr\n                                mat-row\n                                *matRowDef=\"let row; columns: clientColumns;\"\n                                [class.selected]=\"selectedClient === row\"\n                                (click)=\"selectClient(row)\">\n                            </tr>\n                        </table>\n\n                        <div class=\"empty-state\" *ngIf=\"!clients.length && !loading\">\n                            <mat-icon>person_search</mat-icon>\n                            <span>No clients found in this scan</span>\n                        </div>\n                    </div>\n                    <div class=\"pager-row\" *ngIf=\"clients.length\">\n                        <button mat-button (click)=\"prevClientPage()\" [disabled]=\"clientPageIndex === 0\">\n                            <mat-icon>chevron_left</mat-icon>\n                            Previous\n                        </button>\n                        <span>Showing {{ clientPageIndex * pageSize + 1 }}-{{ clientPageIndex * pageSize + pagedClients.length }} of {{ clients.length }}</span>\n                        <button mat-button (click)=\"nextClientPage()\" [disabled]=\"clientPageIndex >= clientPageCount - 1\">\n                            Next\n                            <mat-icon>chevron_right</mat-icon>\n                        </button>\n                    </div>\n                </mat-tab>\n\n                <mat-tab label=\"Handshakes\">\n                    <div class=\"handshake-panel\">\n                        <div class=\"handshake-action-bar\">\n                            <div>\n                                <strong>{{ selectedAp ? selectedAp.ssid : 'No AP selected' }}</strong>\n                                <span>{{ selectedAp ? selectedAp.bssid + ' / CH ' + selectedAp.channel : 'Select an AP or client to target' }}</span>\n                                <small>{{ capturing ? 'Elapsed ' + captureElapsedLabel() : 'Timer ' + captureDurationLabel() }}</small>\n                            </div>\n                            <button class=\"handshake-cta\" mat-raised-button (click)=\"startHandshakeCapture()\" [disabled]=\"capturing || !selectedAp || !captureReady()\">\n                                <mat-icon>vpn_key</mat-icon>\n                                Start Handshake\n                            </button>\n                            <button class=\"danger-action\" mat-raised-button (click)=\"stopHandshakeCapture()\" [disabled]=\"!capturing\">\n                                <mat-icon>stop_circle</mat-icon>\n                                Stop\n                            </button>\n                        </div>\n\n                        <div class=\"pine-dap-panel\">\n                            <div>\n                                <strong>Pine DAP</strong>\n                                <span>Original PineAP handshake.</span>\n                                <small *ngIf=\"pineDapMessage\">{{ pineDapMessage }}</small>\n                            </div>\n                            <div class=\"pine-dap-actions\">\n                                <button class=\"ghost-action\" mat-raised-button (click)=\"startPineDap()\" [disabled]=\"pineDapBusy || !selectedAp\">\n                                    <mat-icon>gesture</mat-icon>\n                                    Pine DAP\n                                </button>\n                                <button class=\"danger-action\" mat-raised-button (click)=\"stopPineDap()\" [disabled]=\"pineDapBusy\">\n                                    <mat-icon>stop_circle</mat-icon>\n                                    Stop DAP\n                                </button>\n                            </div>\n                        </div>\n\n                        <div class=\"handshake-selector\">\n                            <mat-form-field appearance=\"outline\">\n                                <mat-label>Capture Files</mat-label>\n                                <mat-select [(ngModel)]=\"selectedCaptureFile\" (ngModelChange)=\"selectCaptureByFile($event)\" aria-label=\"Handshake capture files\" [disabled]=\"!captures.length\">\n                                    <mat-select-trigger>\n                                        {{ selectedCaptureFile || 'No captures found' }}\n                                    </mat-select-trigger>\n                                    <mat-option *ngFor=\"let capture of captures\" [value]=\"capture.file\">\n                                        <div class=\"capture-option\">\n                                            <div>\n                                                <strong>{{ capture.file }}</strong>\n                                                <small>{{ captureStatusLabel(capture) }} / {{ capture.eapol_frames }} EAPOL</small>\n                                            </div>\n                                            <span class=\"capture-option-actions\">\n                                                <button\n                                                    type=\"button\"\n                                                    mat-icon-button\n                                                    matTooltip=\"Download capture\"\n                                                    (click)=\"downloadCaptureFromMenu($event, capture)\">\n                                                    <mat-icon>file_download</mat-icon>\n                                                </button>\n                                                <button\n                                                    type=\"button\"\n                                                    mat-icon-button\n                                                    matTooltip=\"Delete capture\"\n                                                    (click)=\"deleteCaptureFromMenu($event, capture)\">\n                                                    <mat-icon>delete</mat-icon>\n                                                </button>\n                                            </span>\n                                        </div>\n                                    </mat-option>\n                                </mat-select>\n                            </mat-form-field>\n                            <button class=\"ghost-action\" mat-icon-button matTooltip=\"Refresh captures\" (click)=\"refreshCaptures()\">\n                                <mat-icon>refresh</mat-icon>\n                            </button>\n                            <button class=\"ghost-action\" mat-raised-button (click)=\"downloadSelectedCapture()\" [disabled]=\"!selectedCapture\">\n                                <mat-icon>file_download</mat-icon>\n                                Download PCAP\n                            </button>\n                            <button class=\"danger-action\" mat-raised-button (click)=\"deleteSelectedCapture()\" [disabled]=\"!selectedCapture\">\n                                <mat-icon>delete</mat-icon>\n                                Delete\n                            </button>\n                        </div>\n\n                        <div class=\"handshake-summary\" *ngIf=\"handshakeReport()\">\n                            <div>\n                                <strong>{{ handshakeReport().file }}</strong>\n                                <span>\n                                    {{ captureStatusLabel(handshakeReport()) }} /\n                                    {{ handshakeReport().eapol_frames }} EAPOL frames /\n                                    {{ handshakeReport().pmkid_hashes || 0 }} PMKID /\n                                    {{ handshakeReport().eapol_hashes || 0 }} EAPOL hashes\n                                </span>\n                            </div>\n                            <div class=\"eapol-grid\">\n                                <span [class.found]=\"eapolCount(handshakeReport(), 'M1')\">M1 <em>{{ eapolCount(handshakeReport(), 'M1') }}</em></span>\n                                <span [class.found]=\"eapolCount(handshakeReport(), 'M2')\">M2 <em>{{ eapolCount(handshakeReport(), 'M2') }}</em></span>\n                                <span [class.found]=\"eapolCount(handshakeReport(), 'M3')\">M3 <em>{{ eapolCount(handshakeReport(), 'M3') }}</em></span>\n                                <span [class.found]=\"eapolCount(handshakeReport(), 'M4')\">M4 <em>{{ eapolCount(handshakeReport(), 'M4') }}</em></span>\n                            </div>\n                        </div>\n\n                        <div class=\"capture-status\" *ngIf=\"capturing || handshakeLog\">\n                            <div>\n                                <strong>{{ capturing ? 'Capture running' : 'Last capture output' }}</strong>\n                                <span>{{ selectedAp ? selectedAp.ssid + ' / ' + selectedAp.bssid : 'Any target' }}</span>\n                            </div>\n                            <pre>{{ handshakeLog || 'Waiting for capture output...' }}</pre>\n                        </div>\n\n                        <div class=\"dependency-row\" *ngIf=\"!captureReady()\">\n                            <span>Capture tooling is missing on this Pineapple.</span>\n                            <button mat-raised-button color=\"primary\" (click)=\"installDependencies()\" [disabled]=\"dependencyBusy\">\n                                <mat-icon>file_download</mat-icon>\n                                Install\n                            </button>\n                        </div>\n\n                        <div\n                            class=\"capture-row\"\n                            *ngFor=\"let capture of captures\"\n                            [class.complete]=\"capture.complete\"\n                            [class.selected]=\"selectedCapture === capture\"\n                            (click)=\"selectCapture(capture)\">\n                            <mat-icon>{{ capture.complete ? 'verified_user' : (capture.eapol_frames ? 'key' : 'policy') }}</mat-icon>\n                            <span>{{ capture.file }}</span>\n                            <strong>{{ captureStatusLabel(capture) }}</strong>\n                            <small>\n                                M1 {{ eapolCount(capture, 'M1') }} /\n                                M2 {{ eapolCount(capture, 'M2') }} /\n                                M3 {{ eapolCount(capture, 'M3') }} /\n                                M4 {{ eapolCount(capture, 'M4') }}\n                            </small>\n                            <button\n                                type=\"button\"\n                                class=\"capture-download\"\n                                mat-icon-button\n                                matTooltip=\"Download handshake PCAP\"\n                                (click)=\"$event.stopPropagation(); downloadCapture(capture)\">\n                                <mat-icon>file_download</mat-icon>\n                            </button>\n                        </div>\n\n                        <div class=\"empty-state\" *ngIf=\"!captures.length\">\n                            <mat-icon>vpn_key_off</mat-icon>\n                            <span>No handshake captures found</span>\n                        </div>\n                    </div>\n                </mat-tab>\n            </mat-tab-group>\n        </section>\n    </main>\n</section>\n",
                styles: [".pinerecon-shell{box-sizing:border-box;height:calc(100vh - 84px);min-height:640px;overflow:auto;padding:16px 18px;color:#dffcf9;background:radial-gradient(circle at 18% 18%,rgba(0,206,201,.22),transparent 26%),linear-gradient(145deg,#071114 0,#0b2024 45%,#071719 100%);font-family:Roboto,Arial,sans-serif}.pinerecon-shell *,.pinerecon-shell ::after,.pinerecon-shell ::before{box-sizing:border-box}.pinerecon-shell.light-theme{color:#102527;background:radial-gradient(circle at 18% 18%,rgba(0,168,150,.18),transparent 28%),linear-gradient(145deg,#f6fbfb 0,#e6f5f2 45%,#f8fbff 100%)}.actions,.analysis-strip,.analysis-title,.brand-lockup,.capture-controls,.command-bar,.control-cluster,.dependency-row,.focus-bars,.focus-meta,.recon-grid,.status-strip{display:flex;gap:12px}.command-bar{align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px 14px;margin-bottom:10px}.focus-panel h2{margin:0;letter-spacing:0;overflow-wrap:anywhere}.brand-lockup{align-items:center;min-width:190px}.brand-lockup img{display:block;width:min(210px,44vw);max-height:58px;-o-object-fit:contain;object-fit:contain}.brand-lockup strong{color:#dffcf9;font-size:24px}.eyebrow{margin:0 0 4px;color:#62f7d4;font-size:12px;font-weight:700;text-transform:uppercase}.actions{align-items:center;flex-wrap:wrap;justify-content:flex-end;gap:8px}.control-cluster{align-items:center;flex-wrap:wrap;min-height:38px;padding:3px 6px;border:1px solid rgba(98,247,212,.2);border-radius:8px;background:rgba(7,17,20,.58)}.control-cluster>span{color:#8bb2b0;font-size:11px;font-weight:700;text-transform:uppercase}.control-cluster .mat-button-toggle{color:#dffcf9;background:rgba(3,12,15,.52)}.control-cluster .mat-button-toggle-checked{color:#062325;background:#62f7d4}.theme-cluster mat-form-field{width:118px;margin-bottom:-1.25em}.theme-cluster ::ng-deep .mat-form-field-infix{width:auto;padding:.35em 0 .55em}.danger-action,.ghost-action,.primary-action{min-height:38px;line-height:38px;border-radius:6px;letter-spacing:0;white-space:nowrap}.primary-action{color:#062325;background:#62f7d4;box-shadow:0 0 12px rgba(98,247,212,.16)}.danger-action{color:#ffd5dd;background:rgba(255,92,122,.18);border:1px solid rgba(255,92,122,.42)}.ghost-action{color:#baf7ec;background:rgba(98,247,212,.08);border:1px solid rgba(98,247,212,.28)}.status-strip{align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px}.status-pill{display:inline-flex;align-items:center;gap:7px;min-height:34px;padding:0 12px;border:1px solid rgba(98,247,212,.22);border-radius:6px;color:#c9e7e4;background:rgba(7,17,20,.72)}.status-pill.good{border-color:rgba(61,220,151,.75);color:#7fffc1}.status-pill.muted{color:#8bb2b0}.error{margin:12px 0;padding:10px 12px;border-left:3px solid #ff5c7a;background:rgba(255,92,122,.14);color:#ffd5dd}.dependency-banner{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:12px 0;padding:12px 14px;border:1px solid rgba(255,230,117,.36);border-radius:8px;color:#ffe675;background:rgba(255,230,117,.1)}.dependency-banner small,.dependency-banner span,.dependency-banner strong{display:block}.dependency-banner span{margin-top:3px;color:#dffcf9}.dependency-banner small{margin-top:2px;color:#8bb2b0}.install-cta{min-height:38px;line-height:38px;border-radius:7px;color:#062325;background:#ffe675;font-weight:700;white-space:nowrap}.load-stage{display:flex;align-items:center;gap:12px;margin:12px 0;padding:12px 14px;border:1px solid rgba(98,247,212,.24);border-radius:8px;background:rgba(3,12,15,.72);color:#baf7ec}.scan-loader{position:relative;width:48px;height:28px}.scan-loader span{position:absolute;left:50%;bottom:0;width:12px;height:12px;border:1px solid #62f7d4;border-radius:50%;transform:translateX(-50%);-webkit-animation:1.4s ease-out infinite loader-ping;animation:1.4s ease-out infinite loader-ping}.scan-loader span:nth-child(2){-webkit-animation-delay:.28s;animation-delay:.28s}.scan-loader span:nth-child(3){-webkit-animation-delay:.56s;animation-delay:.56s}.recon-grid{align-items:stretch;margin-top:10px;min-height:0}.data-panel,.radar-panel{border:1px solid rgba(98,247,212,.2);border-radius:8px;background:rgba(3,12,15,.74);box-shadow:0 18px 40px rgba(0,0,0,.28)}.radar-panel{flex:0 0 min(430px,34vw);min-width:340px;padding:14px}.radar{position:relative;width:100%;aspect-ratio:1/1;max-height:430px;overflow:hidden;border:1px solid rgba(98,247,212,.25);border-radius:50%;background:linear-gradient(rgba(98,247,212,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(98,247,212,.08) 1px,transparent 1px),radial-gradient(circle,rgba(54,255,218,.18),rgba(3,12,15,.96) 64%);background-size:28px 28px,28px 28px,100% 100%}.ring{position:absolute;border:1px solid rgba(98,247,212,.32);border-radius:50%;inset:50%;transform:translate(-50%,-50%)}.ring-one{width:32%;height:32%}.ring-two{width:58%;height:58%}.ring-three{width:84%;height:84%}.sweep{position:absolute;inset:0;background:conic-gradient(from 0deg,rgba(98,247,212,.38),rgba(98,247,212,.08) 18deg,transparent 56deg);-webkit-animation:3.4s linear infinite sweep;animation:3.4s linear infinite sweep}.origin{position:absolute;left:50%;top:50%;display:flex;align-items:center;justify-content:center;width:54px;height:54px;border-radius:50%;color:#062325;background:#62f7d4;transform:translate(-50%,-50%);box-shadow:0 0 28px rgba(98,247,212,.65)}.target{position:absolute;width:22px;height:22px;padding:0;border:0;border-radius:50%;background:0 0;transform:translate(-50%,-50%);cursor:pointer}.target span,.target::before{position:absolute;inset:0;border-radius:50%}.target::before{content:\"\";border:1px solid rgba(255,230,117,.72);-webkit-animation:1.8s ease-out infinite ping;animation:1.8s ease-out infinite ping}.target span{inset:7px;background:#ffe675;box-shadow:0 0 14px rgba(255,230,117,.9)}.target.selected span{background:#ff5c7a;box-shadow:0 0 18px rgba(255,92,122,.96)}.focus-panel{margin-top:14px;padding:14px;border:1px solid rgba(98,247,212,.18);border-radius:8px;background:rgba(7,17,20,.88)}.focus-panel p{margin:3px 0 0;color:#8bb2b0}.focus-bars{align-items:flex-end;margin:14px 0}.bars{display:inline-flex;align-items:flex-end;gap:3px;min-width:34px;height:20px;margin-right:8px}.bars span,.focus-bars span{display:inline-block;width:5px;border-radius:2px;background:rgba(139,178,176,.32)}.bars span:nth-child(1),.focus-bars span:nth-child(1){height:6px}.bars span:nth-child(2),.focus-bars span:nth-child(2){height:10px}.bars span:nth-child(3),.focus-bars span:nth-child(3){height:14px}.bars span:nth-child(4),.focus-bars span:nth-child(4){height:18px}.bars span.on,.focus-bars span.on{background:#62f7d4;box-shadow:0 0 10px rgba(98,247,212,.68)}.focus-meta{flex-wrap:wrap}.focus-meta span{padding:6px 9px;border-radius:5px;background:rgba(98,247,212,.1);color:#baf7ec}.client-list{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}.client-list span{padding:5px 8px;border:1px solid rgba(255,230,117,.22);border-radius:5px;color:#ffe675;background:rgba(255,230,117,.08);font-family:monospace}.ap-detail-tools{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.ap-detail-tools button{color:#8bb2b0;background:rgba(3,12,15,.62);border:1px solid rgba(98,247,212,.18)}.ap-detail-tools button.active{color:#062325;background:#62f7d4}.ap-detail-panel{display:-ms-grid;display:grid;gap:8px;margin-top:10px;padding:10px;border:1px solid rgba(98,247,212,.18);border-radius:7px;background:rgba(3,12,15,.46)}.ap-detail-panel strong{color:#dffcf9}.ap-detail-panel p{margin:0;color:#8bb2b0;line-height:1.35}.detail-list{display:-ms-grid;display:grid;gap:6px}.detail-list span{color:#dffcf9}.tagged-table{display:-ms-grid;display:grid;gap:4px;max-height:180px;overflow:auto}.tagged-row{display:-ms-grid;display:grid;-ms-grid-columns:minmax(110px,.7fr) minmax(0,1.3fr);grid-template-columns:minmax(110px,.7fr) minmax(0,1.3fr);gap:8px;padding:7px 8px;border:1px solid rgba(98,247,212,.12);border-radius:5px;color:#dffcf9;background:rgba(7,17,20,.7)}.tagged-row.header{color:#62f7d4;font-weight:700}.intel-grid{display:-ms-grid;display:grid;-ms-grid-columns:(minmax(0,1fr))[2];grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:12px}.intel-card{display:-ms-grid;display:grid;-ms-grid-columns:28px 1fr;grid-template-columns:28px 1fr;gap:2px 8px;min-height:68px;padding:10px;border:1px solid rgba(98,247,212,.16);border-radius:7px;color:#dffcf9;background:rgba(3,12,15,.62);text-align:left;min-width:0}.intel-card mat-icon{-ms-grid-row-span:2;grid-row:span 2;color:#62f7d4}.intel-card strong{color:#baf7ec}.intel-card span{color:#8bb2b0;font-size:12px;overflow-wrap:anywhere}.capture-controls{align-items:center;flex-wrap:wrap;gap:8px;margin-top:14px}.pine-dap-panel,.preflight-panel{display:-ms-grid;display:grid;gap:8px;margin-top:10px;padding:10px;border:1px solid rgba(98,247,212,.18);border-radius:7px;color:#dffcf9;background:rgba(3,12,15,.48)}.pine-dap-panel{-ms-grid-columns:minmax(220px,1fr) auto;grid-template-columns:minmax(220px,1fr) auto;align-items:center;margin-bottom:12px}.pine-dap-panel>div,.preflight-panel>div{display:-ms-grid;display:grid;gap:3px}.pine-dap-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.pine-dap-panel strong,.preflight-panel strong{color:#dffcf9}.pine-dap-panel small,.pine-dap-panel span,.preflight-panel small,.preflight-panel span{color:#8bb2b0}.preflight-panel ul{margin:0;padding-left:18px;color:#ffe675}.preflight-panel li{margin:3px 0}.capture-controls mat-form-field{width:150px;margin-bottom:-1.25em}.capture-controls .interface-select{width:170px}.compact-select{display:inline-flex;align-items:center;gap:7px;min-height:36px;padding:0 8px;border:1px solid rgba(98,247,212,.34);border-radius:6px;background:rgba(3,12,15,.68)}.compact-select span{color:#8bb2b0;font-size:10px;font-weight:700;text-transform:uppercase}.compact-select select{width:92px;border:0;outline:0;color:#dffcf9;background:0 0;font:inherit}.compact-select.short select{width:88px}.compact-select option{color:#dffcf9;background:#071719}.handshake-cta{min-height:40px;line-height:40px;border:1px solid rgba(98,247,212,.7);border-radius:8px;color:#062325;background:#62f7d4;box-shadow:0 0 14px rgba(98,247,212,.18);font-weight:700;letter-spacing:0;white-space:nowrap}.actions ::ng-deep .mat-form-field-outline,.capture-controls ::ng-deep .mat-form-field-outline,.capture-select ::ng-deep .mat-form-field-outline,.handshake-selector ::ng-deep .mat-form-field-outline{color:rgba(98,247,212,.45)}.actions ::ng-deep .mat-form-field-label,.actions ::ng-deep .mat-select-arrow,.actions ::ng-deep .mat-select-value,.capture-controls ::ng-deep .mat-form-field-label,.capture-controls ::ng-deep .mat-select-arrow,.capture-controls ::ng-deep .mat-select-value,.capture-select ::ng-deep .mat-form-field-label,.capture-select ::ng-deep .mat-select-arrow,.capture-select ::ng-deep .mat-select-value,.handshake-selector ::ng-deep .mat-form-field-label,.handshake-selector ::ng-deep .mat-select-arrow,.handshake-selector ::ng-deep .mat-select-value{color:#dffcf9}.actions ::ng-deep .mat-form-field-flex,.capture-controls ::ng-deep .mat-form-field-flex,.capture-select ::ng-deep .mat-form-field-flex,.handshake-selector ::ng-deep .mat-form-field-flex{background:rgba(3,12,15,.68);border-radius:7px}::ng-deep .mat-select-panel{border:1px solid rgba(98,247,212,.32);background:#071719}::ng-deep .mat-option{color:#dffcf9}::ng-deep .mat-option.mat-selected,::ng-deep .mat-option:hover{color:#062325;background:#62f7d4}.data-panel{flex:1 1 auto;min-width:0;overflow:hidden}.data-panel ::ng-deep .mat-tab-label{min-width:128px;color:#baf7ec;opacity:1}.data-panel ::ng-deep .mat-tab-label-active{color:#62f7d4;background:rgba(98,247,212,.08)}.data-panel ::ng-deep .mat-ink-bar{background-color:#62f7d4}.data-panel ::ng-deep .mat-tab-header{border-bottom-color:rgba(98,247,212,.18)}.table-panel{max-height:calc(100vh - 430px);min-height:260px;overflow:auto}.ap-table{min-width:980px}.analysis-strip{align-items:stretch;padding:10px;border-bottom:1px solid rgba(98,247,212,.16)}.analysis-block{flex:1 1 0;min-width:220px;padding:10px;border:1px solid rgba(98,247,212,.14);border-radius:8px;background:rgba(7,17,20,.62)}.analysis-title{align-items:center;margin-bottom:10px;color:#62f7d4;font-weight:700}.stat-row{display:-ms-grid;display:grid;-ms-grid-columns:minmax(54px,.8fr) minmax(90px,2fr) 44px;grid-template-columns:minmax(54px,.8fr) minmax(90px,2fr) 44px;align-items:center;gap:8px;min-height:28px}.stat-row em,.stat-row strong{overflow:hidden;color:#dffcf9;font-size:12px;font-style:normal;text-overflow:ellipsis;white-space:nowrap}.stat-row em{color:#8bb2b0;text-align:right}.stat-track{height:8px;overflow:hidden;border-radius:999px;background:rgba(139,178,176,.22)}.stat-track span{display:block;height:100%;min-width:4px;border-radius:inherit;background:linear-gradient(90deg,#62f7d4,#ffe675);box-shadow:0 0 10px rgba(98,247,212,.42)}.ap-table{width:100%;background:0 0}.ap-table th{color:#62f7d4;font-weight:700}.ap-table td{color:#dffcf9}.ap-table tr.selected td,.ap-table tr:hover td{background:rgba(98,247,212,.09)}.ap-table small{display:block;color:#8bb2b0}.client-table strong{display:block;color:inherit}.client-detail{display:-ms-grid;display:grid;-ms-grid-columns:minmax(160px,.8fr) minmax(260px,2fr) auto;grid-template-columns:minmax(160px,.8fr) minmax(260px,2fr) auto;gap:12px;align-items:center;padding:12px;border-bottom:1px solid rgba(98,247,212,.16);background:rgba(98,247,212,.06)}.client-detail h3{margin:0;color:#dffcf9;font-size:18px}.client-detail>div>span{color:#8bb2b0}.client-detail-grid{display:-ms-grid;display:grid;-ms-grid-columns:(minmax(0,1fr))[3];grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.client-detail-grid span{min-height:44px;padding:7px 9px;border:1px solid rgba(98,247,212,.14);border-radius:6px;color:#dffcf9;background:rgba(3,12,15,.44)}.client-detail-grid strong{display:block;color:#62f7d4;font-size:11px;text-transform:uppercase}.pager-row{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:44px;padding:0 12px;border-top:1px solid rgba(98,247,212,.14);color:#8bb2b0}.pager-row span{color:#baf7ec}.empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;min-height:260px;color:#8bb2b0}.empty-state mat-icon{font-size:44px;width:44px;height:44px}.handshake-panel{max-height:calc(100vh - 360px);min-height:320px;overflow:auto;padding:12px}.handshake-action-bar{position:sticky;top:0;z-index:2;display:-ms-grid;display:grid;-ms-grid-columns:minmax(220px,1fr) auto auto;grid-template-columns:minmax(220px,1fr) auto auto;gap:10px;align-items:center;margin-bottom:12px;padding:12px;border:1px solid rgba(98,247,212,.22);border-radius:8px;background:rgba(7,17,20,.96);box-shadow:0 10px 24px rgba(0,0,0,.24)}.handshake-action-bar strong{display:block;color:#dffcf9}.handshake-action-bar span{color:#8bb2b0}.handshake-action-bar small{display:block;margin-top:3px;color:#8bb2b0}.handshake-selector{display:-ms-grid;display:grid;-ms-grid-columns:minmax(220px,1fr) 42px auto auto;grid-template-columns:minmax(220px,1fr) 42px auto auto;gap:10px;align-items:center;margin-bottom:12px}.handshake-selector mat-form-field{width:100%}.capture-option{display:-ms-grid;display:grid;-ms-grid-columns:minmax(0,1fr) auto;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;width:100%}.capture-option small,.capture-option strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.capture-option strong{color:#dffcf9;font-size:13px}.capture-option small{color:#8bb2b0;font-size:11px}.capture-option-actions{display:inline-flex;align-items:center;gap:2px}.capture-option-actions button{width:30px;height:30px;line-height:30px;color:#baf7ec}.capture-option-actions button:last-child{color:#ff8f9a}.capture-status{margin-bottom:12px;padding:12px;border:1px solid rgba(98,247,212,.18);border-radius:8px;background:rgba(3,12,15,.76)}.handshake-summary{margin-bottom:12px;padding:12px;border:1px solid rgba(98,247,212,.22);border-radius:8px;background:rgba(98,247,212,.08)}.handshake-summary>div:first-child{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px}.handshake-summary strong{color:#dffcf9}.handshake-summary span{color:#8bb2b0}.eapol-grid{display:-ms-grid;display:grid;-ms-grid-columns:(minmax(0,1fr))[4];grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.eapol-grid span{display:flex;align-items:center;justify-content:space-between;min-height:34px;padding:0 10px;border:1px solid rgba(139,178,176,.26);border-radius:6px;color:#8bb2b0;background:rgba(3,12,15,.54);font-weight:700}.eapol-grid span.found{border-color:rgba(98,247,212,.72);color:#62f7d4;box-shadow:0 0 12px rgba(98,247,212,.16)}.eapol-grid em{font-style:normal}.capture-status div{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px}.capture-status strong{color:#62f7d4}.capture-status span{color:#8bb2b0}.capture-status pre{max-height:180px;margin:0;overflow:auto;color:#dffcf9;font-size:12px;white-space:pre-wrap}.dependency-row{align-items:center;justify-content:space-between;margin-bottom:12px;padding:10px 12px;border:1px solid rgba(255,230,117,.32);border-radius:6px;color:#ffe675;background:rgba(255,230,117,.1)}.capture-row{display:-ms-grid;display:grid;-ms-grid-columns:28px minmax(180px,1fr) 92px minmax(160px,.8fr) 42px;grid-template-columns:28px minmax(180px,1fr) 92px minmax(160px,.8fr) 42px;width:100%;min-height:56px;margin-bottom:8px;padding:8px 10px;border:1px solid rgba(98,247,212,.16);border-radius:6px;color:#dffcf9;background:rgba(7,17,20,.86);text-align:left;cursor:pointer}.capture-row>*{-ms-grid-row-align:center;align-self:center}.capture-row.complete{border-color:rgba(61,220,151,.68)}.capture-row.selected,.capture-row:hover{background:rgba(98,247,212,.1)}.capture-row strong{color:#62f7d4;text-transform:uppercase}.capture-row small{color:#8bb2b0}.capture-download{-ms-grid-column-align:end;justify-self:end;color:#baf7ec}.light-theme .analysis-block,.light-theme .ap-detail-panel,.light-theme .capture-row,.light-theme .control-cluster,.light-theme .data-panel,.light-theme .focus-panel,.light-theme .intel-card,.light-theme .load-stage,.light-theme .pine-dap-panel,.light-theme .preflight-panel,.light-theme .radar-panel,.light-theme .status-pill,.light-theme .tagged-row{color:#102527;background:rgba(255,255,255,.78);border-color:rgba(0,126,117,.2)}.light-theme .primary-action{color:#fff;background:#007e75}.light-theme .danger-action{color:#8a1730;background:rgba(255,92,122,.14)}.light-theme .ghost-action{color:#102527;background:rgba(0,126,117,.08)}.light-theme .handshake-cta{color:#fff;background:#007e75}.light-theme .install-cta{color:#102527;background:#ffe675}.light-theme .client-detail,.light-theme .handshake-action-bar{background:rgba(255,255,255,.86);border-color:rgba(0,126,117,.2)}.light-theme .client-detail h3,.light-theme .client-detail-grid span,.light-theme .handshake-action-bar strong{color:#102527}.light-theme .client-detail-grid span{background:rgba(0,126,117,.06)}.light-theme .data-panel ::ng-deep .mat-tab-label{color:#244b4c}.light-theme .data-panel ::ng-deep .mat-tab-label-active{color:#102527;background:rgba(0,126,117,.08)}.light-theme .actions ::ng-deep .mat-form-field-label,.light-theme .actions ::ng-deep .mat-select-arrow,.light-theme .actions ::ng-deep .mat-select-value,.light-theme .capture-controls ::ng-deep .mat-form-field-label,.light-theme .capture-controls ::ng-deep .mat-select-arrow,.light-theme .capture-controls ::ng-deep .mat-select-value,.light-theme .capture-select ::ng-deep .mat-form-field-label,.light-theme .capture-select ::ng-deep .mat-select-arrow,.light-theme .capture-select ::ng-deep .mat-select-value,.light-theme .handshake-selector ::ng-deep .mat-form-field-label,.light-theme .handshake-selector ::ng-deep .mat-select-arrow,.light-theme .handshake-selector ::ng-deep .mat-select-value{color:#102527}.light-theme .actions ::ng-deep .mat-form-field-flex,.light-theme .capture-controls ::ng-deep .mat-form-field-flex,.light-theme .capture-select ::ng-deep .mat-form-field-flex,.light-theme .capture-status,.light-theme .handshake-selector ::ng-deep .mat-form-field-flex{background:rgba(255,255,255,.84)}.light-theme .dependency-banner,.light-theme .dependency-banner small,.light-theme .dependency-banner span{color:#102527}.light-theme .dependency-banner{background:rgba(255,230,117,.28);border-color:rgba(134,103,0,.24)}.light-theme .client-list span,.light-theme .compact-select,.light-theme .focus-meta span{color:#102527;background:rgba(0,126,117,.08)}.light-theme .ap-detail-tools button{color:#102527;background:rgba(0,126,117,.08);border-color:rgba(0,126,117,.2)}.light-theme .ap-detail-tools button.active{color:#fff;background:#007e75}.light-theme .compact-select select,.light-theme .compact-select span{color:#102527}.light-theme .compact-select option{color:#102527;background:#fff}.light-theme .capture-status pre{color:#102527}.light-theme .eapol-grid span,.light-theme .handshake-summary{background:rgba(255,255,255,.78)}.light-theme .analysis-title,.light-theme .ap-detail-panel p,.light-theme .ap-detail-panel strong,.light-theme .ap-table th,.light-theme .capture-row strong,.light-theme .capture-status strong,.light-theme .detail-list span,.light-theme .eapol-grid span,.light-theme .eapol-grid span.found,.light-theme .eyebrow,.light-theme .focus-panel h2,.light-theme .focus-panel strong,.light-theme .handshake-summary strong,.light-theme .intel-card span,.light-theme .intel-card strong,.light-theme .pine-dap-panel small,.light-theme .pine-dap-panel span,.light-theme .pine-dap-panel strong,.light-theme .preflight-panel li,.light-theme .preflight-panel small,.light-theme .preflight-panel span,.light-theme .preflight-panel strong,.light-theme .tagged-row,.light-theme .tagged-row.header{color:#102527}.light-theme .radar{background:linear-gradient(rgba(0,126,117,.1) 1px,transparent 1px),linear-gradient(90deg,rgba(0,126,117,.1) 1px,transparent 1px),radial-gradient(circle,rgba(0,168,150,.18),rgba(255,255,255,.96) 64%);background-size:28px 28px,28px 28px,100% 100%}.light-theme .ap-table td,.light-theme .capture-row,.light-theme .intel-card,.light-theme .stat-row strong{color:#102527}.light-theme .ap-table small,.light-theme .capture-row small,.light-theme .empty-state,.light-theme .focus-panel p{color:#557170}.light-theme .pager-row span{color:#102527}.red-theme{color:#ffe8e8;background:radial-gradient(circle at 18% 18%,rgba(255,40,76,.22),transparent 27%),linear-gradient(145deg,#110607 0,#260c12 48%,#12080a 100%)}.red-theme .analysis-block,.red-theme .capture-row,.red-theme .capture-status,.red-theme .control-cluster,.red-theme .data-panel,.red-theme .eapol-grid span,.red-theme .focus-panel,.red-theme .handshake-action-bar,.red-theme .handshake-summary,.red-theme .intel-card,.red-theme .load-stage,.red-theme .radar-panel,.red-theme .status-pill{color:#ffe8e8;background:rgba(18,6,8,.84);border-color:rgba(255,63,98,.28)}.red-theme .analysis-title,.red-theme .ap-table th,.red-theme .capture-status strong,.red-theme .client-detail-grid strong,.red-theme .data-panel ::ng-deep .mat-tab-label-active,.red-theme .eyebrow{color:#ff496d}.red-theme .handshake-cta,.red-theme .install-cta{color:#210509;background:#ff496d;border-color:rgba(255,73,109,.72);box-shadow:0 0 24px rgba(255,73,109,.3)}.red-theme .bars span.on,.red-theme .control-cluster .mat-button-toggle-checked,.red-theme .focus-bars span.on,.red-theme .origin{background:#ff496d;color:#210509;box-shadow:0 0 14px rgba(255,73,109,.68)}.red-theme .stat-track span{background:linear-gradient(90deg,#ff496d,#ffcf5a)}.red-theme .radar{background:linear-gradient(rgba(255,73,109,.09) 1px,transparent 1px),linear-gradient(90deg,rgba(255,73,109,.09) 1px,transparent 1px),radial-gradient(circle,rgba(255,73,109,.16),rgba(18,6,8,.96) 64%);background-size:28px 28px,28px 28px,100% 100%}.red-theme .sweep{background:conic-gradient(from 0deg,rgba(255,73,109,.4),rgba(255,207,90,.1) 18deg,transparent 56deg)}.red-theme .data-panel ::ng-deep .mat-ink-bar{background-color:#ff496d}.cobalt-theme{color:#eaf5ff;background:radial-gradient(circle at 18% 18%,rgba(0,187,255,.18),transparent 27%),linear-gradient(145deg,#071018 0,#102233 48%,#07121a 100%)}.cobalt-theme .analysis-block,.cobalt-theme .capture-row,.cobalt-theme .capture-status,.cobalt-theme .control-cluster,.cobalt-theme .data-panel,.cobalt-theme .eapol-grid span,.cobalt-theme .focus-panel,.cobalt-theme .handshake-action-bar,.cobalt-theme .handshake-summary,.cobalt-theme .intel-card,.cobalt-theme .load-stage,.cobalt-theme .radar-panel,.cobalt-theme .status-pill{color:#eaf5ff;background:rgba(7,16,24,.84);border-color:rgba(61,193,255,.24)}.cobalt-theme .analysis-title,.cobalt-theme .ap-table th,.cobalt-theme .capture-status strong,.cobalt-theme .client-detail-grid strong,.cobalt-theme .data-panel ::ng-deep .mat-tab-label-active,.cobalt-theme .eyebrow{color:#5fd4ff}.cobalt-theme .handshake-cta,.cobalt-theme .install-cta{color:#061522;background:#5fd4ff;border-color:rgba(95,212,255,.68)}.cobalt-theme .bars span.on,.cobalt-theme .control-cluster .mat-button-toggle-checked,.cobalt-theme .focus-bars span.on,.cobalt-theme .origin{background:#5fd4ff;color:#061522;box-shadow:0 0 14px rgba(95,212,255,.68)}.cobalt-theme .stat-track span{background:linear-gradient(90deg,#5fd4ff,#9cffb4)}.cobalt-theme .radar{background:linear-gradient(rgba(95,212,255,.09) 1px,transparent 1px),linear-gradient(90deg,rgba(95,212,255,.09) 1px,transparent 1px),radial-gradient(circle,rgba(95,212,255,.16),rgba(7,16,24,.96) 64%);background-size:28px 28px,28px 28px,100% 100%}.cobalt-theme .sweep{background:conic-gradient(from 0deg,rgba(95,212,255,.38),rgba(156,255,180,.1) 18deg,transparent 56deg)}.cobalt-theme .data-panel ::ng-deep .mat-ink-bar{background-color:#5fd4ff}@-webkit-keyframes sweep{to{transform:rotate(360deg)}}@keyframes sweep{to{transform:rotate(360deg)}}@-webkit-keyframes loader-ping{0%{opacity:1;transform:translateX(-50%) scale(.35)}100%{opacity:0;transform:translateX(-50%) scale(2.8)}}@keyframes loader-ping{0%{opacity:1;transform:translateX(-50%) scale(.35)}100%{opacity:0;transform:translateX(-50%) scale(2.8)}}@-webkit-keyframes ping{0%{opacity:.9;transform:scale(.65)}100%{opacity:0;transform:scale(2.3)}}@keyframes ping{0%{opacity:.9;transform:scale(.65)}100%{opacity:0;transform:scale(2.3)}}@media (max-width:980px){.pinerecon-shell{height:auto;min-height:100%}.command-bar{white-space:normal}.recon-grid{flex-direction:column}.radar-panel{flex-basis:auto;min-width:0}.radar{max-width:520px;margin:0 auto}.actions{width:100%;justify-content:flex-start}.analysis-strip{flex-wrap:wrap}.client-detail,.handshake-action-bar,.handshake-selector,.pine-dap-panel{-ms-grid-columns:1fr;grid-template-columns:1fr}.handshake-action-bar{position:static}}@media (max-width:640px){.pinerecon-shell{padding:12px}.actions,.actions mat-button-toggle-group,.actions mat-form-field,.capture-controls mat-form-field,.compact-select,.control-cluster,.danger-action,.ghost-action,.handshake-cta,.pine-dap-actions,.primary-action{width:100%}.brand-lockup{width:100%;justify-content:center}.theme-cluster mat-button-toggle-group{width:auto}.dependency-banner,.install-cta,.theme-cluster mat-form-field{width:100%}.dependency-banner{align-items:stretch;flex-direction:column}.scan-time{align-items:flex-start;flex-direction:column}.capture-controls{align-items:stretch;flex-direction:column}.compact-select{justify-content:space-between;min-height:42px}.compact-select select,.compact-select.short select{width:min(190px,58vw)}.radar-panel{padding:10px}.handshake-panel,.table-panel{max-height:none}.client-detail-grid{-ms-grid-columns:1fr;grid-template-columns:1fr}.pager-row{flex-wrap:wrap;justify-content:center;padding:8px}.analysis-strip,.intel-grid{-ms-grid-columns:1fr;grid-template-columns:1fr}.analysis-strip{display:-ms-grid;display:grid}.tagged-row{-ms-grid-columns:1fr;grid-template-columns:1fr}.eapol-grid{-ms-grid-columns:(minmax(0,1fr))[2];grid-template-columns:repeat(2,minmax(0,1fr))}.capture-row{-ms-grid-columns:28px 1fr 42px;grid-template-columns:28px 1fr 42px;min-height:72px}.capture-row small,.capture-row strong{-ms-grid-column:2;grid-column:2}.capture-download{-ms-grid-column:3;grid-column:3;-ms-grid-row:1;-ms-grid-row-span:3;grid-row:1/span 3}}"]
            })
        ], PineReconComponent);
        return PineReconComponent;
    }());

    /*
     * Copyright (c) 2018 Hak5 LLC.
     */
    var MaterialModule = /** @class */ (function () {
        function MaterialModule() {
        }
        MaterialModule = __decorate([
            core.NgModule({
                imports: [common.CommonModule],
                exports: [
                    // CDK
                    a11y.A11yModule,
                    bidi.BidiModule,
                    observers.ObserversModule,
                    overlay.OverlayModule,
                    platform.PlatformModule,
                    portal.PortalModule,
                    stepper.CdkStepperModule,
                    table.CdkTableModule,
                    tree.CdkTreeModule,
                    // Material
                    autocomplete.MatAutocompleteModule,
                    badge.MatBadgeModule,
                    bottomSheet.MatBottomSheetModule,
                    button.MatButtonModule,
                    buttonToggle.MatButtonToggleModule,
                    card.MatCardModule,
                    checkbox.MatCheckboxModule,
                    chips.MatChipsModule,
                    datepicker.MatDatepickerModule,
                    dialog.MatDialogModule,
                    divider.MatDividerModule,
                    expansion.MatExpansionModule,
                    formField.MatFormFieldModule,
                    gridList.MatGridListModule,
                    icon.MatIconModule,
                    input.MatInputModule,
                    list.MatListModule,
                    menu.MatMenuModule,
                    core$1.MatNativeDateModule,
                    paginator.MatPaginatorModule,
                    progressBar.MatProgressBarModule,
                    progressSpinner.MatProgressSpinnerModule,
                    radio.MatRadioModule,
                    core$1.MatRippleModule,
                    select.MatSelectModule,
                    sidenav.MatSidenavModule,
                    slider.MatSliderModule,
                    slideToggle.MatSlideToggleModule,
                    snackBar.MatSnackBarModule,
                    sort.MatSortModule,
                    stepper$1.MatStepperModule,
                    table$1.MatTableModule,
                    tabs.MatTabsModule,
                    toolbar.MatToolbarModule,
                    tooltip.MatTooltipModule,
                    tree$1.MatTreeModule,
                ],
                declarations: []
            })
        ], MaterialModule);
        return MaterialModule;
    }());

    var routes = [
        { path: '', component: PineReconComponent }
    ];
    var PineReconModule = /** @class */ (function () {
        function PineReconModule() {
        }
        PineReconModule = __decorate([
            core.NgModule({
                declarations: [PineReconComponent],
                imports: [
                    common.CommonModule,
                    router.RouterModule.forChild(routes),
                    MaterialModule,
                    flexLayout.FlexLayoutModule,
                    forms.FormsModule,
                ],
                exports: [PineReconComponent]
            })
        ], PineReconModule);
        return PineReconModule;
    }());

    exports.PineReconComponent = PineReconComponent;
    exports.PineReconModule = PineReconModule;
    exports.PineReconService = PineReconService;
    exports.ɵa = ApiService;
    exports.ɵb = MaterialModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=PineRecon.umd.js.map
